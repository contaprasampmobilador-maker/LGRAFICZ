package com.lzia.smartgraph

import org.junit.Assert.assertTrue
import org.junit.Test

class CandlePatternRecognizerTest {
    private fun candle(direction: String, top: Int, bodyTop: Int, bodyBottom: Int, bottom: Int) =
        ScreenGraphAnalyzer.Candle(direction, 100, top, bottom, bodyTop, bodyBottom, 0f)

    @Test fun recognizesDoji() {
        val result = CandlePatternRecognizer.recognize(listOf(candle("ALTA", 10, 49, 50, 90)))
        assertTrue(result.any { it.name.contains("Doji") })
    }

    @Test fun recognizesBullishEngulfing() {
        val candles = listOf(
            candle("BAIXA", 20, 30, 70, 80),
            candle("ALTA", 10, 25, 75, 90)
        )
        val result = CandlePatternRecognizer.recognize(candles)
        assertTrue(result.any { it.name == "Engolfo de alta (Bullish Engulfing)" })
    }

    @Test fun recognizesBullishHaramiCross() {
        val candles = listOf(
            candle("BAIXA", 20, 30, 70, 80),
            candle("ALTA", 35, 49, 50, 65)
        )
        val result = CandlePatternRecognizer.recognize(candles)
        assertTrue(result.any { it.name == "Harami cruzado de alta (Bullish Harami Cross)" })
    }

    @Test fun recognizesHammerAfterDownMove() {
        val candles = listOf(
            candle("BAIXA", 10, 15, 45, 50),
            candle("BAIXA", 15, 20, 50, 55),
            candle("BAIXA", 20, 25, 55, 60),
            candle("ALTA", 43, 45, 55, 90)
        )
        val result = CandlePatternRecognizer.recognize(candles)
        assertTrue(result.any { it.name == "Martelo (Hammer)" })
    }
}
