package com.lzia.smartgraph

import org.junit.Assert.assertEquals
import org.junit.Test

class ScreenGraphAnalyzerTrendTest {
    private fun candle(direction: String, closeY: Int, x: Int) =
        if (direction == "ALTA") ScreenGraphAnalyzer.Candle(direction, x, closeY - 4, closeY + 2, closeY, closeY + 1, 0.2f)
        else ScreenGraphAnalyzer.Candle(direction, x, closeY - 2, closeY + 4, closeY - 1, closeY, 0.2f)

    @Test fun identifiesRisingVisualTrend() {
        val candles = (0 until 7).map { candle("ALTA", 120 - it * 12, it * 20) }
        assertEquals("ALTA", ScreenGraphAnalyzer.estimateTrend(candles))
    }

    @Test fun identifiesFallingVisualTrend() {
        val candles = (0 until 7).map { candle("BAIXA", 30 + it * 12, it * 20) }
        assertEquals("BAIXA", ScreenGraphAnalyzer.estimateTrend(candles))
    }

    @Test fun requiresEnoughCandles() {
        assertEquals("INDEFINIDA", ScreenGraphAnalyzer.estimateTrend(emptyList()))
    }
}
