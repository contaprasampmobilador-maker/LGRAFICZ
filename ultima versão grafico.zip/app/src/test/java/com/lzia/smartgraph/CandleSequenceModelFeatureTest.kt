package com.lzia.smartgraph

import org.junit.Assert.assertEquals
import org.junit.Test

class CandleSequenceModelFeatureTest {
    @Test fun featureVectorHasSixFiniteValues() {
        val candles = (0 until 8).map { i ->
            ScreenGraphAnalyzer.Candle(
                direction = if (i % 2 == 0) "ALTA" else "BAIXA",
                xCenter = i * 10, top = 10, bottom = 30,
                bodyTop = 15, bodyBottom = 25, wickRatio = 0.5f
            )
        }
        val features = ScreenGraphAnalyzer.sequenceFeatures(candles)
        assertEquals(CandleSequenceModel.FEATURE_COUNT, features.size)
        assertEquals(0.0, features[0], 0.0001)
        assertEquals(11.0/21.0, features[1], 0.0001)
        assertEquals(0.5, features[2], 0.0001)
        assertEquals(-1.0, features[3], 0.0001)
        assertEquals(-0.111111, features[4], 0.001)
    }
}
