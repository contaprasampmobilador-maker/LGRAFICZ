package com.lzia.smartgraph

import org.junit.Assert.assertEquals
import org.junit.Test

class IndicatorEngineTest {
    @Test fun insufficientInputWaits() {
        assertEquals("AGUARDAR", IndicatorEngine.analyze("1.0,1.1,1.2").signal)
    }

    @Test fun risingSeriesProducesBullishTechnicalSignal() {
        val prices = (1..60).joinToString(",") { (1.0 + it * 0.01).toString() }
        assertEquals("SUBIR", IndicatorEngine.analyze(prices).signal)
    }

    @Test fun fallingSeriesProducesBearishTechnicalSignal() {
        val prices = (1..60).joinToString(",") { (2.0 - it * 0.01).toString() }
        assertEquals("DESCER", IndicatorEngine.analyze(prices).signal)
    }

    @Test fun flatSeriesWaits() {
        val prices = List(60) { "1.25000" }.joinToString(",")
        assertEquals("AGUARDAR", IndicatorEngine.analyze(prices).signal)
    }
}
