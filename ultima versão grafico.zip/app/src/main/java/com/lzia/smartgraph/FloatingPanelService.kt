package com.lzia.smartgraph

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Painel flutuante compacto, arrastável e expansível do SmartGraphPredictor. */
class FloatingPanelService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelBody: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var expanded = false
    private var detailsVisible = false

    private var latestSignal = "AGUARDAR"
    private var latestMessage = "Aguardando captura do gráfico"
    private var latestCandles = 0
    private var latestConfidence = 0
    private var latestPattern = "Padrão não identificado"
    private var latestPatternDescription = "Aguardando análise"
    private var latestPatterns: List<String> = emptyList()
    private var latestTrend = "INDEFINIDA"

    private val analysisReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != GraphCaptureService.ACTION_ANALYSIS) return
            latestSignal = intent.getStringExtra(GraphCaptureService.EXTRA_SIGNAL) ?: "AGUARDAR"
            latestMessage = intent.getStringExtra(GraphCaptureService.EXTRA_MESSAGE) ?: "Sem detalhes"
            latestCandles = intent.getIntExtra(GraphCaptureService.EXTRA_CANDLES, 0)
            latestConfidence = intent.getIntExtra(GraphCaptureService.EXTRA_CONFIDENCE, 0)
            latestPattern = intent.getStringExtra(GraphCaptureService.EXTRA_PATTERN) ?: "Padrão não identificado"
            latestPatternDescription = intent.getStringExtra(GraphCaptureService.EXTRA_PATTERN_DESCRIPTION) ?: "Aguardando análise"
            latestPatterns = intent.getStringArrayExtra(GraphCaptureService.EXTRA_PATTERNS)?.toList() ?: emptyList()
            latestTrend = intent.getStringExtra(GraphCaptureService.EXTRA_TREND) ?: "INDEFINIDA"
            updatePanel()
        }
    }

    override fun onCreate() {
        super.onCreate()
        val filter = IntentFilter(GraphCaptureService.ACTION_ANALYSIS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(analysisReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(analysisReceiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_HIDE) {
            removeViews()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Log.e(TAG, "Permissão de sobreposição não concedida")
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) showBubble()
        return START_STICKY
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(16); y = dp(230) }

        bubble = TextView(this).apply {
            text = latestSignal
            textSize = 12f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundColor(signalColor())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            contentDescription = "SmartGraphPredictor: $latestSignal. Toque para abrir o painel. Arraste para mover."
            setOnTouchListener(object : View.OnTouchListener {
                private var downX = 0f
                private var downY = 0f
                private var startX = 0
                private var startY = 0
                private var moved = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = e.rawX; downY = e.rawY
                            startX = bubbleParams.x; startY = bubbleParams.y
                            moved = false
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (e.rawX - downX).toInt()
                            val dy = (e.rawY - downY).toInt()
                            if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                            bubbleParams.x = startX - dx
                            bubbleParams.y = (startY + dy).coerceAtLeast(dp(24))
                            try { windowManager?.updateViewLayout(bubble, bubbleParams) } catch (_: Exception) {}
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!moved) togglePanel()
                            return true
                        }
                    }
                    return true
                }
            })
        }
        try { windowManager?.addView(bubble, bubbleParams) }
        catch (e: Exception) {
            Log.e(TAG, "Falha ao exibir a bolha", e)
            bubble = null
            stopSelf()
        }
    }

    private fun togglePanel() {
        if (expanded) {
            panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
            panel = null
            panelBody = null
            panelParams = null
            expanded = false
            detailsVisible = false
        } else {
            showPanel()
        }
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(12, 10, 24))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = label("SMARTGRAPH  3.3 BETA", 13f, Color.rgb(190, 125, 255), true)
        header.addView(title, LinearLayout.LayoutParams(0, dp(38), 1f))
        val close = label("×", 24f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { togglePanel() }
            contentDescription = "Fechar painel"
        }
        header.addView(close, LinearLayout.LayoutParams(dp(36), dp(38)))
        attachDrag(header)
        root.addView(header)
        root.addView(separator())

        val signal = label(latestSignal, 25f, signalColor(), true).apply { gravity = Gravity.CENTER }
        root.addView(signal, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(label("Padrão: $latestPattern", 14f, Color.WHITE, true))
        root.addView(label("Tendência: $latestTrend", 13f, Color.rgb(100, 220, 190), false))
        root.addView(label("Confiança visual: ${latestConfidence.coerceIn(0, 100)}%  •  Candles: $latestCandles", 11f, MUTED, false))

        val detailsButton = label(if (detailsVisible) "OCULTAR DETALHES  ▴" else "VER DETALHES  ▾", 12f, Color.rgb(190, 125, 255), true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(8))
            setOnClickListener { detailsVisible = !detailsVisible; rebuildDetails() }
        }
        root.addView(detailsButton)
        panelBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(panelBody)
        root.addView(label("Arraste pelo cabeçalho • Toque na bolha para fechar", 9f, MUTED, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })

        panel = root
        panelParams = WindowManager.LayoutParams(
            dp(270), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(300) }
        try {
            windowManager?.addView(root, panelParams)
            expanded = true
            rebuildDetails()
        } catch (e: Exception) {
            Log.e(TAG, "Falha ao abrir painel", e)
            panel = null; panelBody = null; panelParams = null
        }
    }

    private fun rebuildDetails() {
        val body = panelBody ?: return
        body.removeAllViews()
        if (!detailsVisible) return
        body.addView(separator())
        body.addView(label(latestPatternDescription, 12f, Color.WHITE, false))
        body.addView(label("Outros padrões: ${latestPatterns.drop(1).take(4).joinToString(", ").ifBlank { "nenhum identificado" }}", 11f, MUTED, false))
        body.addView(label(latestMessage, 11f, MUTED, false))
        body.addView(label("A leitura visual pode falhar. Confirme os dados; não é recomendação financeira.", 10f, Color.rgb(255, 195, 105), false))
    }

    private fun attachDrag(view: View) {
        view.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f; private var downY = 0f
            private var startX = 0; private var startY = 0
            private var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = panelParams ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=p.x; startY=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt()
                        if (abs(dx)>dp(5) || abs(dy)>dp(5)) moved=true
                        p.x=(startX-dx).coerceAtLeast(0); p.y=(startY+dy).coerceAtLeast(dp(24))
                        try { windowManager?.updateViewLayout(panel, p) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> return moved
                }
                return false
            }
        })
    }

    private fun updatePanel() {
        bubble?.apply {
            text = latestSignal
            setBackgroundColor(signalColor())
            contentDescription = "SmartGraphPredictor: $latestSignal. Toque para abrir o painel."
        }
        if (expanded) {
            // Reconstrói o painel para manter os dados sincronizados sem alterar sua posição.
            val old = panel ?: return
            val oldParams = panelParams ?: return
            val wasExpanded = detailsVisible
            try { windowManager?.removeView(old) } catch (_: Exception) {}
            panel = null; panelBody = null; panelParams = null; expanded = false
            showPanel()
            detailsVisible = wasExpanded
            rebuildDetails()
            panelParams?.let { newParams ->
                newParams.x = oldParams.x; newParams.y = oldParams.y
                try { windowManager?.updateViewLayout(panel, newParams) } catch (_: Exception) {}
            }
        }
    }

    private fun panelText(): String = "Sinal: $latestSignal\nPadrão: $latestPattern\nTendência: $latestTrend"
    private fun label(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(3))
    }
    private fun separator() = View(this).apply {
        setBackgroundColor(Color.rgb(75, 52, 105))
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(5); bottomMargin = dp(7) }
    }
    private fun signalColor(): Int = when (latestSignal) {
        "SUBIR" -> Color.rgb(0, 135, 75)
        "DESCER" -> Color.rgb(175, 45, 65)
        else -> Color.rgb(105, 85, 35)
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun removeViews() {
        panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        panel = null; panelBody = null; bubble = null; panelParams = null; expanded = false
    }

    override fun onDestroy() {
        try { unregisterReceiver(analysisReceiver) } catch (_: Exception) {}
        removeViews()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_SHOW = "com.lzia.smartgraph.SHOW_FLOATING"
        const val ACTION_HIDE = "com.lzia.smartgraph.HIDE_FLOATING"
        private const val TAG = "SmartGraphPredictor"
        private val MUTED = Color.rgb(183, 175, 197)
    }
}
