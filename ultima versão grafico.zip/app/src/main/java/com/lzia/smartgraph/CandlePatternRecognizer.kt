package com.lzia.smartgraph

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Rule-based recognition of widely used single-, double- and triple-candle patterns.
 * Inputs are geometry estimates from a screenshot, not exchange OHLC data. Therefore
 * matches are labelled as visual/experimental and should be confirmed in chart context.
 */
object CandlePatternRecognizer {
    data class Match(
        val name: String,
        val bias: String,
        val candles: Int,
        val description: String,
        val strength: Int
    )

    private data class Shape(
        val c: ScreenGraphAnalyzer.Candle,
        val range: Float,
        val body: Float,
        val upper: Float,
        val lower: Float,
        val bodyRatio: Float
    ) {
        val bullish get() = c.direction == "ALTA"
        val bearish get() = c.direction == "BAIXA"
        val bodyHigh get() = c.bodyTop.toFloat() // smaller screen y = higher chart price
        val bodyLow get() = c.bodyBottom.toFloat()
        val high get() = c.top.toFloat()
        val low get() = c.bottom.toFloat()
        val midpoint get() = (bodyHigh + bodyLow) / 2f
    }

    fun recognize(candles: List<ScreenGraphAnalyzer.Candle>): List<Match> {
        if (candles.isEmpty()) return emptyList()
        val s = candles.map { c ->
            val range = (c.bottom - c.top + 1).toFloat().coerceAtLeast(1f)
            val body = (c.bodyBottom - c.bodyTop + 1).toFloat().coerceAtLeast(1f).coerceAtMost(range)
            Shape(c, range, body,
                (c.bodyTop - c.top).toFloat().coerceAtLeast(0f),
                (c.bottom - c.bodyBottom).toFloat().coerceAtLeast(0f),
                body / range)
        }
        val out = mutableListOf<Match>()
        val a = s.last()
        val prev = s.getOrNull(s.lastIndex - 1)
        val p2 = s.getOrNull(s.lastIndex - 2)

        // One-candle patterns
        if (a.bodyRatio <= 0.10f) {
            val longLower = a.lower >= a.range * 0.60f && a.upper <= a.range * 0.12f
            val longUpper = a.upper >= a.range * 0.60f && a.lower <= a.range * 0.12f
            when {
                longLower -> out += match("Doji libélula (Dragonfly Doji)", "POSSÍVEL ALTA", 1, "Corpo muito pequeno e pavio inferior longo; precisa de contexto de queda.", 78)
                longUpper -> out += match("Doji lápide (Gravestone Doji)", "POSSÍVEL BAIXA", 1, "Corpo muito pequeno e pavio superior longo; precisa de contexto de alta.", 78)
                max(a.upper, a.lower) >= a.range * 0.35f -> out += match("Doji de pernas longas", "INDEFINIDO", 1, "Indecisão entre compradores e vendedores.", 70)
                else -> out += match("Doji", "INDEFINIDO", 1, "Abertura e fechamento visualmente próximos; indica indecisão.", 75)
            }
        } else {
            if (a.bodyRatio >= 0.88f && a.upper <= a.range * 0.07f && a.lower <= a.range * 0.07f) {
                out += match(if (a.bullish) "Marubozu de alta" else "Marubozu de baixa", if (a.bullish) "POSSÍVEL ALTA" else "POSSÍVEL BAIXA", 1, "Corpo dominante com pavios mínimos.", 82)
            }
            if (a.bodyRatio <= 0.32f && a.upper >= a.body * 0.55f && a.lower >= a.body * 0.55f) {
                out += match("Pião (Spinning Top)", "INDEFINIDO", 1, "Corpo pequeno e pavios nos dois lados; mostra equilíbrio/indecisão.", 68)
            }
            if (a.bodyRatio >= 0.72f && a.bullish && a.lower <= a.range * 0.06f) {
                out += match("Linha de sustentação de alta (Bullish Belt Hold)", "POSSÍVEL ALTA", 1, "Candle de alta com abertura visual próxima da mínima e corpo longo.", 73)
            }
            if (a.bodyRatio >= 0.72f && a.bearish && a.upper <= a.range * 0.06f) {
                out += match("Linha de resistência de baixa (Bearish Belt Hold)", "POSSÍVEL BAIXA", 1, "Candle de baixa com abertura visual próxima da máxima e corpo longo.", 73)
            }
            val hammerShape = a.lower >= a.body * 2f && a.upper <= a.body * 0.45f
            val starShape = a.upper >= a.body * 2f && a.lower <= a.body * 0.45f
            val priorDown = s.take(max(0, s.lastIndex)).takeLast(3).count { it.bearish } >= 2
            val priorUp = s.take(max(0, s.lastIndex)).takeLast(3).count { it.bullish } >= 2
            if (hammerShape) {
                if (priorDown) out += match("Martelo (Hammer)", "POSSÍVEL ALTA", 1, "Pavio inferior longo após movimento de baixa; aguarde confirmação.", 80)
                if (priorUp) out += match("Enforcado (Hanging Man)", "POSSÍVEL BAIXA", 1, "Formato de martelo após movimento de alta; aguarde confirmação.", 76)
                if (!priorDown && !priorUp) out += match("Formato de martelo", "INDEFINIDO", 1, "Formato reconhecido, mas sem tendência anterior clara.", 62)
            }
            if (starShape) {
                if (priorDown) out += match("Martelo invertido (Inverted Hammer)", "POSSÍVEL ALTA", 1, "Pavio superior longo após baixa; precisa de confirmação.", 76)
                if (priorUp) out += match("Estrela cadente (Shooting Star)", "POSSÍVEL BAIXA", 1, "Pavio superior longo após alta; precisa de confirmação.", 80)
                if (!priorDown && !priorUp) out += match("Formato de estrela", "INDEFINIDO", 1, "Pavio superior longo sem tendência anterior identificável.", 62)
            }
        }

        // Two-candle patterns
        if (prev != null) {
            val bodyEngulfs = a.bodyHigh <= prev.bodyHigh && a.bodyLow >= prev.bodyLow && a.body >= prev.body * 1.05f
            if (prev.bearish && a.bullish && bodyEngulfs) out += match("Engolfo de alta (Bullish Engulfing)", "POSSÍVEL ALTA", 2, "Corpo atual de alta envolve o corpo anterior de baixa.", 88)
            if (prev.bullish && a.bearish && bodyEngulfs) out += match("Engolfo de baixa (Bearish Engulfing)", "POSSÍVEL BAIXA", 2, "Corpo atual de baixa envolve o corpo anterior de alta.", 88)
            val insideBody = a.bodyHigh >= prev.bodyHigh && a.bodyLow <= prev.bodyLow
            if (prev.bearish && insideBody && a.bodyRatio <= 0.10f) {
                out += match("Harami cruzado de alta (Bullish Harami Cross)", "POSSÍVEL ALTA", 2, "Doji atual contido no corpo anterior de baixa; requer contexto de queda.", 77)
            }
            if (prev.bullish && insideBody && a.bodyRatio <= 0.10f) {
                out += match("Harami cruzado de baixa (Bearish Harami Cross)", "POSSÍVEL BAIXA", 2, "Doji atual contido no corpo anterior de alta; requer contexto de alta.", 77)
            }
            if (prev.bearish && a.bullish && insideBody && a.bodyRatio > 0.10f && a.body <= prev.body * 0.75f) out += match("Harami de alta (Bullish Harami)", "POSSÍVEL ALTA", 2, "Corpo menor de alta contido no corpo anterior de baixa.", 76)
            if (prev.bullish && a.bearish && insideBody && a.bodyRatio > 0.10f && a.body <= prev.body * 0.75f) out += match("Harami de baixa (Bearish Harami)", "POSSÍVEL BAIXA", 2, "Corpo menor de baixa contido no corpo anterior de alta.", 76)

            val midpointPrev = prev.midpoint
            if (prev.bearish && a.bullish && a.bodyHigh < midpointPrev && a.bodyHigh > prev.bodyHigh && a.bodyLow >= prev.bodyLow) {
                out += match("Linha de perfuração (Piercing Line)", "POSSÍVEL ALTA", 2, "Candle de alta recupera mais da metade do corpo de baixa anterior.", 78)
            }
            if (prev.bullish && a.bearish && a.bodyLow > midpointPrev && a.bodyLow < prev.bodyLow && a.bodyHigh <= prev.bodyHigh) {
                out += match("Cobertura de nuvem escura (Dark Cloud Cover)", "POSSÍVEL BAIXA", 2, "Candle de baixa devolve mais da metade do corpo de alta anterior.", 78)
            }

            val tolerance = max(3f, (prev.range + a.range) * 0.06f)
            if (abs(a.high - prev.high) <= tolerance) out += match("Pinça de topo (Tweezer Top)", "POSSÍVEL BAIXA", 2, "Máximas visuais em nível semelhante.", 72)
            if (abs(a.low - prev.low) <= tolerance) out += match("Pinça de fundo (Tweezer Bottom)", "POSSÍVEL ALTA", 2, "Mínimas visuais em nível semelhante.", 72)
            if (a.high >= prev.high && a.low <= prev.low && a.range > prev.range * 1.15f) out += match("Candle externo (Outside Bar)", if (a.bullish) "POSSÍVEL ALTA" else "POSSÍVEL BAIXA", 1, "Amplitude atual envolve a amplitude anterior.", 65)
            if (a.high <= prev.high && a.low >= prev.low && a.range < prev.range * 0.90f) out += match("Candle interno (Inside Bar)", "INDEFINIDO", 1, "Amplitude atual está contida na anterior; pode indicar consolidação.", 68)
        }

        // Three-candle patterns
        if (prev != null && p2 != null) {
            val smallMiddle = prev.body <= min(p2.body, a.body) * 0.65f
            if (p2.bearish && p2.bodyRatio >= 0.50f && smallMiddle && a.bullish && a.bodyRatio >= 0.45f && a.bodyHigh < p2.midpoint) {
                out += match("Estrela da manhã (Morning Star)", "POSSÍVEL ALTA", 3, "Sequência de baixa, candle de indecisão e recuperação de alta.", 86)
            }
            if (p2.bullish && p2.bodyRatio >= 0.50f && smallMiddle && a.bearish && a.bodyRatio >= 0.45f && a.bodyLow > p2.midpoint) {
                out += match("Estrela da noite (Evening Star)", "POSSÍVEL BAIXA", 3, "Sequência de alta, candle de indecisão e reversão de baixa.", 86)
            }
            val threeUp = listOf(p2, prev, a)
            if (threeUp.all { it.bullish && it.bodyRatio >= 0.45f } && p2.bodyHigh > prev.bodyHigh && prev.bodyHigh > a.bodyHigh && p2.bodyLow < prev.bodyLow && prev.bodyLow < a.bodyLow) {
                out += match("Três soldados brancos (Three White Soldiers)", "POSSÍVEL ALTA", 3, "Três candles consecutivos de alta com corpos relevantes.", 84)
            }
            if (threeUp.all { it.bearish && it.bodyRatio >= 0.45f } && p2.bodyHigh < prev.bodyHigh && prev.bodyHigh < a.bodyHigh && p2.bodyLow > prev.bodyLow && prev.bodyLow > a.bodyLow) {
                out += match("Três corvos negros (Three Black Crows)", "POSSÍVEL BAIXA", 3, "Três candles consecutivos de baixa com corpos relevantes.", 84)
            }
            if (p2.bearish && prev.bullish && prev.bodyHigh > p2.bodyHigh && prev.bodyLow < p2.bodyLow && a.bullish && a.bodyHigh < p2.bodyHigh) {
                out += match("Três dentro para cima (Three Inside Up)", "POSSÍVEL ALTA", 3, "Harami de alta seguido por candle de confirmação acima do corpo inicial.", 82)
            }
            if (p2.bullish && prev.bearish && prev.bodyHigh < p2.bodyHigh && prev.bodyLow > p2.bodyLow && a.bearish && a.bodyLow > p2.bodyLow) {
                out += match("Três dentro para baixo (Three Inside Down)", "POSSÍVEL BAIXA", 3, "Harami de baixa seguido por candle de confirmação abaixo do corpo inicial.", 82)
            }
            val middleEngulfsFirstBull = p2.bearish && prev.bullish && prev.bodyHigh <= p2.bodyHigh && prev.bodyLow >= p2.bodyLow
            val middleEngulfsFirstBear = p2.bullish && prev.bearish && prev.bodyHigh <= p2.bodyHigh && prev.bodyLow >= p2.bodyLow
            if (middleEngulfsFirstBull && a.bullish && a.bodyHigh < prev.bodyHigh) {
                out += match("Três fora para cima (Three Outside Up)", "POSSÍVEL ALTA", 3, "Engolfo de alta seguido por candle de continuação.", 82)
            }
            if (middleEngulfsFirstBear && a.bearish && a.bodyLow > prev.bodyLow) {
                out += match("Três fora para baixo (Three Outside Down)", "POSSÍVEL BAIXA", 3, "Engolfo de baixa seguido por candle de continuação.", 82)
            }
        }

        // Five-candle continuation patterns (approximate; screenshot geometry cannot verify gaps).
        if (s.size >= 5) {
            val q = s.takeLast(5)
            val first = q.first(); val last = q.last(); val middle = q.subList(1, 4)
            if (first.bullish && first.bodyRatio > 0.5f && last.bullish && last.bodyRatio > 0.5f && middle.all { it.body < first.body * 0.65f && it.high <= first.high && it.low >= first.low }) {
                out += match("Método de alta de três (Rising Three Methods)", "POSSÍVEL ALTA", 5, "Candle de alta, pausa contida e retomada de alta; gaps não são verificáveis pela captura.", 74)
            }
            if (first.bearish && first.bodyRatio > 0.5f && last.bearish && last.bodyRatio > 0.5f && middle.all { it.body < first.body * 0.65f && it.high <= first.high && it.low >= first.low }) {
                out += match("Método de baixa de três (Falling Three Methods)", "POSSÍVEL BAIXA", 5, "Candle de baixa, pausa contida e retomada de baixa; gaps não são verificáveis pela captura.", 74)
            }
        }

        // Keep strongest matches first; multiple matches can coexist because patterns overlap.
        return out.distinctBy { it.name }.sortedByDescending { it.strength }
    }

    private fun match(name: String, bias: String, candles: Int, description: String, strength: Int) =
        Match(name, bias, candles, description, strength)
}
