package com.lzia.smartgraph

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.view.WindowManager

class GraphCaptureService : Service() {
    private var model: CandleSequenceModel? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null
    private var lastAnalysisAt = 0L
    private var projectionCallback: MediaProjection.Callback? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        if (model == null) model = CandleSequenceModel.fromAssets(this)
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("SmartGraphPredictor ativo")
            .setContentText("Análise visual experimental em execução no aparelho")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(41, notification)

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                   else @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
        if (resultCode != 0 && data != null && projection == null) {
            try {
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = manager.getMediaProjection(resultCode, data)
                projectionCallback = object : MediaProjection.Callback() {
                    override fun onStop() {
                        stopCapture()
                        stopSelf()
                    }
                }
                projection?.registerCallback(projectionCallback!!, Handler(mainLooper))
                startProjectionCapture()
            } catch (e: Exception) {
                android.util.Log.e("SmartGraphPredictor", "Não foi possível iniciar a captura", e)
                stopCapture()
                stopSelf()
            }
        } else if (projection == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startProjectionCapture() {
        val thread = HandlerThread("SmartGraphFrameWorker").apply { start() }
        workerThread = thread
        worker = Handler(thread.looper)

        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi
        imageReader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 3)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = SystemClock.elapsedRealtime()
            if (now - lastAnalysisAt < ANALYSIS_INTERVAL_MS) {
                reader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            lastAnalysisAt = now
            worker?.post {
                try {
                    val bitmap = imageToBitmap(image)
                    val result = ScreenGraphAnalyzer.analyze(bitmap, model)
                    publishResult(result)
                    bitmap.recycle()
                } catch (e: Exception) {
                    publishResult(ScreenGraphAnalyzer.Result("AGUARDAR", 0, 0, "Falha ao analisar a captura"))
                } finally {
                    image.close()
                }
            } ?: image.close()
        }, worker)

        virtualDisplay = projection?.createVirtualDisplay(
            "SmartGraphPredictor-Capture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, worker
        )
    }

    /** Downsamples while reading the Image, avoiding a full-resolution bitmap allocation. */
    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val widthScale = (image.width + MAX_FRAME_WIDTH - 1) / MAX_FRAME_WIDTH
        val heightScale = (image.height + MAX_FRAME_HEIGHT - 1) / MAX_FRAME_HEIGHT
        val scale = maxOf(1, maxOf(widthScale, heightScale))
        val outWidth = (image.width + scale - 1) / scale
        val outHeight = (image.height + scale - 1) / scale
        val pixels = IntArray(outWidth * outHeight)
        for (outY in 0 until outHeight) {
            val y = minOf(outY * scale, image.height - 1)
            val rowStart = y * rowStride
            for (outX in 0 until outWidth) {
                val x = minOf(outX * scale, image.width - 1)
                val offset = rowStart + x * pixelStride
                val r = buffer.get(offset).toInt() and 0xFF
                val g = buffer.get(offset + 1).toInt() and 0xFF
                val b = buffer.get(offset + 2).toInt() and 0xFF
                val a = buffer.get(offset + 3).toInt() and 0xFF
                pixels[outY * outWidth + outX] = Color.argb(a, r, g, b)
            }
        }
        return Bitmap.createBitmap(pixels, outWidth, outHeight, Bitmap.Config.ARGB_8888)
    }

    private fun publishResult(result: ScreenGraphAnalyzer.Result) {
        sendBroadcast(Intent(ACTION_ANALYSIS).setPackage(packageName).apply {
            putExtra(EXTRA_SIGNAL, result.signal)
            putExtra(EXTRA_CANDLES, result.candles)
            putExtra(EXTRA_CONFIDENCE, result.confidence)
            putExtra(EXTRA_MESSAGE, result.message)
            putExtra(EXTRA_PATTERN, result.currentPattern)
            putExtra(EXTRA_PATTERN_DESCRIPTION, result.patternDescription)
            putExtra(EXTRA_PATTERNS, result.matchedPatterns.toTypedArray())
            putExtra(EXTRA_TREND, result.trend)
        })
    }

    private fun stopCapture() {
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close(); imageReader = null
        projectionCallback?.let { callback -> try { projection?.unregisterCallback(callback) } catch (_: Exception) {} }
        projectionCallback = null
        val oldProjection = projection
        projection = null
        try { oldProjection?.stop() } catch (_: Exception) {}
        workerThread?.quitSafely(); workerThread = null; worker = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        publishResult(ScreenGraphAnalyzer.Result("AGUARDAR", 0, 0, "Captura interrompida"))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "SmartGraphPredictor", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() { stopCapture(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.lzia.smartgraph.START_CAPTURE"
        const val ACTION_STOP = "com.lzia.smartgraph.STOP_CAPTURE"
        const val ACTION_ANALYSIS = "com.lzia.smartgraph.SCREEN_ANALYSIS"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_SIGNAL = "signal"
        const val EXTRA_CANDLES = "candles"
        const val EXTRA_CONFIDENCE = "confidence"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_PATTERN = "pattern"
        const val EXTRA_PATTERN_DESCRIPTION = "pattern_description"
        const val EXTRA_PATTERNS = "patterns"
        const val EXTRA_TREND = "trend"
        const val CHANNEL = "lzia_capture_channel"
        private const val ANALYSIS_INTERVAL_MS = 2000L
        private const val MAX_FRAME_WIDTH = 720
        private const val MAX_FRAME_HEIGHT = 960
    }
}
