package com.lzia.smartgraph

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF07050D)
private val CardBg = Color(0xFF151020)
private val Purple = Color(0xFFB45CFF)
private val Purple2 = Color(0xFF7437D6)
private val Cyan = Color(0xFF55DFFF)
private val Green = Color(0xFF45E58A)
private val Red = Color(0xFFFF647C)
private val Muted = Color(0xFFB7AFC5)

class MainActivity : ComponentActivity() {
    private var waitingForOverlayPermission = false
    private var waitingToStartCapture = false
    private var screenAnalysis by mutableStateOf(
        ScreenGraphAnalyzer.Result("AGUARDAR", 0, 0, "Aguardando captura do gráfico")
    )
    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != GraphCaptureService.ACTION_ANALYSIS) return
            screenAnalysis = ScreenGraphAnalyzer.Result(
                intent.getStringExtra(GraphCaptureService.EXTRA_SIGNAL) ?: "AGUARDAR",
                intent.getIntExtra(GraphCaptureService.EXTRA_CANDLES, 0),
                intent.getIntExtra(GraphCaptureService.EXTRA_CONFIDENCE, 0),
                intent.getStringExtra(GraphCaptureService.EXTRA_MESSAGE) ?: "Sem detalhes",
                currentPattern = intent.getStringExtra(GraphCaptureService.EXTRA_PATTERN) ?: "Padrão não identificado",
                patternDescription = intent.getStringExtra(GraphCaptureService.EXTRA_PATTERN_DESCRIPTION) ?: "Aguardando análise",
                matchedPatterns = intent.getStringArrayExtra(GraphCaptureService.EXTRA_PATTERNS)?.toList() ?: emptyList(),
                trend = intent.getStringExtra(GraphCaptureService.EXTRA_TREND) ?: "INDEFINIDA"
            )
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(GraphCaptureService.ACTION_ANALYSIS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(captureReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(captureReceiver, filter)
    }

    override fun onStop() {
        try { unregisterReceiver(captureReceiver) } catch (_: Exception) {}
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = false
            if (waitingToStartCapture) {
                waitingToStartCapture = false
                beginScreenCaptureConsent()
            } else {
                showFloatingBubble()
            }
        }
    }

    private fun showFloatingBubble() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            startService(Intent(this, FloatingPanelService::class.java).setAction(FloatingPanelService.ACTION_SHOW))
        } catch (e: Exception) {
            android.util.Log.e("LRAPHZ", "Não foi possível iniciar a bolha", e)
        }
    }

    private fun requestOverlayPermission() {
        waitingForOverlayPermission = true
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun beginScreenCaptureConsent() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, GraphCaptureService::class.java).apply {
                action = GraphCaptureService.ACTION_START
                putExtra(GraphCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(GraphCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            showFloatingBubble()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple, secondary = Cyan, background = Bg, surface = CardBg,
                onBackground = Color.White, onSurface = Color.White
            )) {
                LraphzApp(
                    onActivate = { activateLraphz() },
                    screenAnalysis = screenAnalysis,
                    onStop = {
                        stopService(Intent(this, GraphCaptureService::class.java))
                        stopService(Intent(this, FloatingPanelService::class.java))
                    },
                    onOverlayPermission = { requestOverlayPermission() }
                )
            }
        }
    }

    private fun activateLraphz() {
        if (!Settings.canDrawOverlays(this)) {
            waitingToStartCapture = true
            requestOverlayPermission()
            return
        }
        showFloatingBubble()
        beginScreenCaptureConsent()
    }
}

@Composable
private fun LraphzApp(onActivate: () -> Unit, screenAnalysis: ScreenGraphAnalyzer.Result, onStop: () -> Unit, onOverlayPermission: () -> Unit) {
    var page by remember { mutableStateOf("home") }
    var active by remember { mutableStateOf(false) }
    var prices by remember { mutableStateOf("1.1000,1.1002,1.1001,1.1005,1.1007,1.1006,1.1009,1.1012,1.1010,1.1014,1.1016,1.1015,1.1018,1.1020,1.1019,1.1023,1.1025,1.1024,1.1027,1.1030,1.1032,1.1031,1.1034,1.1036,1.1035,1.1038,1.1040,1.1039,1.1042,1.1044,1.1043,1.1046,1.1048,1.1047,1.1050") }
    var analysis by remember { mutableStateOf(IndicatorEngine.analyze(prices)) }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF180B29), Bg, Color(0xFF05040A))))) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                if (page != "home") {
                    IconButton(onClick = { page = "home" }) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
                } else {
                    Box(Modifier.size(42.dp).background(Purple.copy(alpha = .18f), CircleShape).border(1.dp, Purple, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Insights, null, tint = Purple, modifier = Modifier.size(25.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("SmartGraphPredictor", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 2.sp)
                    Text("ANÁLISE INTELIGENTE DE GRÁFICOS", fontSize = 8.sp, color = Cyan, letterSpacing = 2.sp)
                }
                Surface(color = if (active) Green.copy(alpha = .15f) else Color.White.copy(alpha = .07f), shape = CircleShape) {
                    Text(if (active) "● ATIVO" else "● OFFLINE", color = if (active) Green else Muted, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp))
                }
            }

            when (page) {
                "home" -> HomeScreen(
                    onStart = { page = "dashboard" },
                    onSettings = { page = "settings" },
                    onActivate = { onActivate(); active = true }
                )
                "dashboard" -> DashboardScreen(
                    prices = prices,
                    onPricesChange = { prices = it },
                    analysis = analysis,
                    screenAnalysis = screenAnalysis,
                    onAnalyze = { analysis = IndicatorEngine.analyze(prices) },
                    onSettings = { page = "settings" },
                    onStop = { onStop(); active = false }
                )
                else -> SettingsScreen(onOverlayPermission = onOverlayPermission, onActivate = { onActivate(); active = true }, onStop = { onStop(); active = false })
            }
        }
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xFF0C0913)).padding(vertical = 9.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            NavItem("Início", Icons.Default.Home, page == "home") { page = "home" }
            NavItem("Gráfico", Icons.Default.CandlestickChart, page == "dashboard") { page = "dashboard" }
            NavItem("Ajustes", Icons.Default.Settings, page == "settings") { page = "settings" }
        }
    }
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = if (selected) Purple else Muted)
            Text(label, color = if (selected) Purple else Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun HomeScreen(onStart: () -> Unit, onSettings: () -> Unit, onActivate: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(210.dp).background(Brush.linearGradient(listOf(Color(0xFF32115B), Color(0xFF11101E), Color(0xFF071B2B))), RoundedCornerShape(26.dp)).border(1.dp, Purple.copy(alpha = .65f), RoundedCornerShape(26.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Insights, null, tint = Purple, modifier = Modifier.size(62.dp))
                Text("SmartGraphPredictor", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 4.sp)
                Text("INTELIGÊNCIA PARA LEITURA DE GRÁFICOS", fontSize = 9.sp, color = Cyan, letterSpacing = 1.sp)
                Text("ANALISE • ACOMPANHE • COMPARE", fontSize = 9.sp, color = Muted)
            }
        }
        Text("Seu painel de análise", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Acompanhe indicadores técnicos em uma interface simples e organizada.", color = Muted, fontSize = 13.sp)
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple2)) {
            Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(9.dp)); Text("INICIAR PAINEL", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        OutlinedButton(onClick = onActivate, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
            Icon(Icons.Default.Tune, null); Spacer(Modifier.width(8.dp)); Text("ATIVAR CAPTURA E BOLHA")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FeatureCard("Indicadores", "EMA • RSI • MACD", Modifier.weight(1f))
            FeatureCard("Painel", "Visão resumida", Modifier.weight(1f))
        }
        Text("Importante: os indicadores são cálculos técnicos sobre preços fornecidos por você. Não são previsões garantidas nem probabilidades validadas.", color = Color(0xFFFFD477), fontSize = 11.sp)
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Purple, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun DashboardScreen(prices: String, onPricesChange: (String) -> Unit, analysis: AnalysisResult, screenAnalysis: ScreenGraphAnalyzer.Result, onAnalyze: () -> Unit, onSettings: () -> Unit, onStop: () -> Unit) {
    val priceValues = remember(prices) { prices.split(',', ';', '\n', ' ', '\t').mapNotNull { it.trim().replace(',', '.').toFloatOrNull() }.filter { it > 0f } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).padding(bottom = 92.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("PAINEL DE MONITORAMENTO", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Cyan.copy(alpha = .45f), RoundedCornerShape(20.dp))) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CAPTURA AUTOMÁTICA • LEITURA BETA", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(screenAnalysis.signal, color = when (screenAnalysis.signal) { "SUBIR" -> Green; "DESCER" -> Red; else -> Color(0xFFFFD477) }, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text("Candles detectados: ${screenAnalysis.candles} • Concordância de cores: ${screenAnalysis.confidence}%", color = Muted, fontSize = 11.sp)
                Text("Tendência visual: ${screenAnalysis.trend}", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Divider(color = Color(0xFF39284D))
                Text("PADRÃO DE CANDLE ATUAL", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(screenAnalysis.currentPattern, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(screenAnalysis.patternDescription, color = Muted, fontSize = 11.sp)
                if (screenAnalysis.matchedPatterns.isNotEmpty()) {
                    Text("Outros padrões detectados: ${screenAnalysis.matchedPatterns.drop(1).take(4).joinToString(" • ")}", color = Muted, fontSize = 10.sp)
                }
                Text(screenAnalysis.message, color = Muted, fontSize = 11.sp)
                Text("Reconhecimento visual experimental; não representa probabilidade de acerto.", color = Color(0xFFFFD477), fontSize = 10.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Purple.copy(alpha = .6f), RoundedCornerShape(22.dp))) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("LEITURA ATUAL", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        Text(analysis.signal, color = when (analysis.signal) { "SUBIR" -> Green; "DESCER" -> Red; else -> Color(0xFFFFD477) }, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    }
                    Icon(Icons.Default.Insights, null, tint = Purple, modifier = Modifier.size(42.dp))
                }
                Text("Direção sugerida pelos indicadores — não é uma chance percentual real.", color = Muted, fontSize = 11.sp)
                Divider(color = Color(0xFF39284D))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricChip("EMA 9", analysis.ema9, Modifier.weight(1f))
                    MetricChip("EMA 21", analysis.ema21, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricChip("RSI 14", analysis.rsi, Modifier.weight(1f))
                    MetricChip("MACD", analysis.macd, Modifier.weight(1f))
                }
                Text(analysis.reason, color = Muted, fontSize = 11.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("GRÁFICO DE PREÇOS INSERIDOS", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                if (priceValues.size >= 2) PriceLineChart(priceValues) else Text("Insira pelo menos dois valores para desenhar o gráfico.", color = Muted)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ATUALIZAR DADOS", color = Purple, fontWeight = FontWeight.Bold)
                Text("Cole preços de fechamento separados por vírgula. A atualização ocorre quando você toca em analisar.", color = Muted, fontSize = 11.sp)
                OutlinedTextField(value = prices, onValueChange = onPricesChange, modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text("Lista de preços") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                Button(onClick = onAnalyze, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple2)) { Text("ANALISAR AGORA") }
            }
        }
        OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Icon(Icons.Default.Stop, null); Spacer(Modifier.width(8.dp)); Text("PARAR CAPTURA") }
        Text("A leitura visual experimental procura formatos estreitos e verticais, estima corpo e pavios pela distribuição de pixels e classifica a cor dominante. Não extrai OHLC real nem prevê o próximo candle. A concordância visual não é probabilidade de acerto. Em caso de dúvida, use AGUARDAR.", color = Color(0xFFFFD477), fontSize = 11.sp)
    }
}

@Composable
private fun MetricChip(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0xFF211832), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(11.dp)) {
            Text(label, color = Muted, fontSize = 10.sp)
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PriceLineChart(values: List<Float>) {
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val min = values.minOrNull() ?: 0f
        val max = values.maxOrNull() ?: 1f
        val range = (max - min).takeIf { it > 0f } ?: 1f
        for (i in 1..3) {
            val y = size.height * i / 4f
            drawLine(Color(0xFF39284D), Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
        }
        val pts = values.mapIndexed { index, value ->
            Offset(size.width * index / (values.size - 1).coerceAtLeast(1), size.height - ((value - min) / range) * (size.height - 12.dp.toPx()) - 6.dp.toPx())
        }
        pts.zipWithNext().forEach { (a, b) -> drawLine(Purple, a, b, 3.dp.toPx()) }
        pts.forEach { drawCircle(Cyan, 3.dp.toPx(), it) }
    }
}

@Composable
private fun SettingsScreen(onOverlayPermission: () -> Unit, onActivate: () -> Unit, onStop: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).padding(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("CONFIGURAÇÕES", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Permissões e controle dos recursos do LRAPHZ.", color = Muted)
        Button(onClick = onOverlayPermission, modifier = Modifier.fillMaxWidth()) { Text("PERMITIR BOLHA SOBRE OUTROS APPS") }
        OutlinedButton(onClick = onActivate, modifier = Modifier.fillMaxWidth()) { Text("INICIAR CAPTURA DE TELA") }
        OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Text("PARAR SERVIÇOS") }
        Text("Privacidade: a captura só começa após autorização explícita do Android. O processamento visual desta versão é feito localmente e não envia imagens para servidores.", color = Muted, fontSize = 12.sp)
        Text("Versão 3.3.0-beta • SmartGraphPredictor", color = Purple, fontSize = 12.sp)
    }
}
