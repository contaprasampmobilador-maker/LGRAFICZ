package com.lzia.smartgraph

import android.content.Context
import org.json.JSONObject
import kotlin.math.exp
import kotlin.math.sqrt

/** Optional on-device multiclass logistic model. A model is usable only after
 * tools/train_candle_model.py writes a trained model.json from labeled examples. */
class CandleSequenceModel private constructor(
    private val means: DoubleArray,
    private val scales: DoubleArray,
    private val weights: Array<DoubleArray>,
    private val bias: DoubleArray,
    val trained: Boolean,
    val trainingRows: Int
) {
    data class Prediction(val label: String, val score: Int, val margin: Double)

    fun predict(features: DoubleArray): Prediction? {
        if (!trained || features.size != FEATURE_COUNT) return null
        val labels = arrayOf("DESCER", "AGUARDAR", "SUBIR")
        val logits = DoubleArray(3) { c ->
            bias[c] + (0 until FEATURE_COUNT).sumOf { i ->
                weights[c][i] * ((features[i] - means[i]) / scales[i])
            }
        }
        val maxLogit = logits.maxOrNull() ?: return null
        val exps = logits.map { exp((it - maxLogit).coerceIn(-40.0, 40.0)) }
        val total = exps.sum().takeIf { it > 0.0 } ?: return null
        val probs = exps.map { it / total }
        val ranked = probs.indices.sortedByDescending { probs[it] }
        val best = ranked[0]
        val margin = probs[best] - probs[ranked[1]]
        // Abstain on uncertain predictions. Scores are model scores, not win probabilities.
        val label = if (probs[best] < 0.58 || margin < 0.16) "AGUARDAR" else labels[best]
        return Prediction(label, (probs[best] * 100).toInt(), margin)
    }

    companion object {
        const val FEATURE_COUNT = 6
        fun fromAssets(context: Context): CandleSequenceModel? = try {
            val json = context.assets.open("market_model.json").bufferedReader().use { it.readText() }
            val root = JSONObject(json)
            val trained = root.optBoolean("trained", false)
            val rows = root.optInt("training_rows", 0)
            val means = root.getJSONArray("means").toDoubleArray()
            val scales = root.getJSONArray("scales").toDoubleArray()
            val weightRows = root.getJSONArray("weights")
            val weights = Array(3) { c -> weightRows.getJSONArray(c).toDoubleArray() }
            val bias = root.getJSONArray("bias").toDoubleArray()
            if (means.size != FEATURE_COUNT || scales.size != FEATURE_COUNT ||
                weights.any { it.size != FEATURE_COUNT } || bias.size != 3 || scales.any { it <= 0.0 }) null
            else CandleSequenceModel(means, scales, weights, bias, trained, rows)
        } catch (_: Exception) { null }

        private fun org.json.JSONArray.toDoubleArray(): DoubleArray =
            DoubleArray(length()) { getDouble(it) }
    }
}
