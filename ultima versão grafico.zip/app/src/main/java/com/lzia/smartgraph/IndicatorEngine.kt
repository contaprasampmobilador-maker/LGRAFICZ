package com.lzia.smartgraph

import java.util.Locale
import kotlin.math.abs

data class AnalysisResult(
    val signal: String,
    val ema9: String,
    val ema21: String,
    val rsi: String,
    val macd: String,
    val reason: String
)

/** Technical-indicator calculator for manually supplied closing prices. */
object IndicatorEngine {
    fun analyze(input: String): AnalysisResult {
        // Commas, semicolons, whitespace and line breaks are separators. Decimal point is used.
        val prices = input.split(Regex("[,;\\s]+"))
            .mapNotNull { it.trim().replace(',', '.').toDoubleOrNull() }
            .filter { it.isFinite() && it > 0.0 }
        if (prices.size < 35) {
            return AnalysisResult(
                "AGUARDAR", "—", "—", "—", "—",
                "Dados insuficientes: informe pelo menos 35 preços positivos, usando ponto nos decimais."
            )
        }

        val ema9Series = emaSeries(prices, 9)
        val ema21Series = emaSeries(prices, 21)
        val ema9 = ema9Series.last()
        val ema21 = ema21Series.last()
        val rsi = rsiWilder(prices, 14)

        // MACD = EMA(12)-EMA(26); displayed value is its histogram (MACD minus signal EMA(9)).
        val ema12 = emaSeries(prices, 12)
        val ema26 = emaSeries(prices, 26)
        val macdLine = prices.indices.map { ema12[it] - ema26[it] }
        val macdSignal = emaSeries(macdLine, 9).last()
        val macdHistogram = macdLine.last() - macdSignal

        var score = 0
        if (ema9 > ema21) score++ else if (ema9 < ema21) score--
        if (rsi >= 55.0) score++ else if (rsi <= 45.0) score--
        if (macdHistogram > 0.0) score++ else if (macdHistogram < 0.0) score--

        val signal = when {
            score >= 2 -> "SUBIR"
            score <= -2 -> "DESCER"
            else -> "AGUARDAR"
        }
        val trend = when {
            ema9 > ema21 -> "EMA9 acima da EMA21"
            ema9 < ema21 -> "EMA9 abaixo da EMA21"
            else -> "EMAs praticamente alinhadas"
        }
        val reason = "$trend; RSI ${fmt(rsi)}; histograma MACD ${if (macdHistogram >= 0) "positivo" else "negativo"}. " +
            "Pontuação técnica $score/3. Regra heurística, sem probabilidade validada."
        return AnalysisResult(signal, fmt(ema9), fmt(ema21), fmt(rsi), fmt(macdHistogram), reason)
    }

    private fun emaSeries(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val alpha = 2.0 / (period + 1.0)
        var current = values.first()
        return values.map { value ->
            current = alpha * value + (1.0 - alpha) * current
            current
        }
    }

    private fun rsiWilder(values: List<Double>, period: Int): Double {
        if (values.size <= period) return 50.0
        val changes = values.zipWithNext { a, b -> b - a }
        var averageGain = changes.take(period).sumOf { it.coerceAtLeast(0.0) } / period
        var averageLoss = changes.take(period).sumOf { (-it).coerceAtLeast(0.0) } / period
        for (change in changes.drop(period)) {
            averageGain = (averageGain * (period - 1) + change.coerceAtLeast(0.0)) / period
            averageLoss = (averageLoss * (period - 1) + (-change).coerceAtLeast(0.0)) / period
        }
        if (averageLoss == 0.0) return if (averageGain == 0.0) 50.0 else 100.0
        return 100.0 - 100.0 / (1.0 + averageGain / averageLoss)
    }

    private fun fmt(value: Double): String = String.format(Locale.US, "%.5f", value)
}
