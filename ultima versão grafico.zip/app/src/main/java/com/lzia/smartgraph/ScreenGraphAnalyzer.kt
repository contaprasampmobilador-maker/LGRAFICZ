package com.lzia.smartgraph

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

/**
 * Heuristic candle-shape detector for screenshots. It looks for narrow, vertically
 * extended red/green components and estimates each candle's body and wick from its
 * colored-pixel distribution. This is computer vision by rules, NOT a trained model.
 * It deliberately returns AGUARDAR when the screenshot is ambiguous.
 */
object ScreenGraphAnalyzer {
    data class Candle(
        val direction: String,
        val xCenter: Int,
        val top: Int,
        val bottom: Int,
        val bodyTop: Int,
        val bodyBottom: Int,
        val wickRatio: Float
    )

    data class Result(
        val signal: String,
        val candles: Int,
        /** Agreement of recent detected candle colors; never a win probability. */
        val confidence: Int,
        val message: String,
        val detected: List<Candle> = emptyList(),
        val currentPattern: String = "Padrão não identificado",
        val patternDescription: String = "Aguardando candles legíveis",
        val matchedPatterns: List<String> = emptyList(),
        val trend: String = "INDEFINIDA"
    )

    private data class Column(
        var green: Int = 0,
        var red: Int = 0,
        var minY: Int = Int.MAX_VALUE,
        var maxY: Int = Int.MIN_VALUE
    ) {
        val total: Int get() = green + red
    }

    fun analyze(bitmap: Bitmap, model: CandleSequenceModel? = null): Result {
        if (bitmap.width < 160 || bitmap.height < 160) {
            return waiting("Imagem pequena demais para análise visual")
        }

        // Exclude typical status/navigation bars while retaining most chart layouts.
        val left = (bitmap.width * 0.04f).toInt()
        val right = (bitmap.width * 0.96f).toInt()
        val top = (bitmap.height * 0.12f).toInt()
        val bottom = (bitmap.height * 0.88f).toInt()
        val binWidth = max(1, bitmap.width / 720)
        val bins = ((right - left) + binWidth - 1) / binWidth
        val columns = Array(bins) { Column() }
        val stride = max(1, max(bitmap.width / 900, bitmap.height / 1200))

        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                val hi = max(r, max(g, b))
                val lo = min(r, min(g, b))
                val saturated = hi - lo >= 58
                val isGreen = saturated && g >= 95 && g > r * 1.22f && g > b * 1.10f
                val isRed = saturated && r >= 105 && r > g * 1.22f && r > b * 1.10f
                if (isGreen || isRed) {
                    val index = ((x - left) / binWidth).coerceIn(0, bins - 1)
                    val col = columns[index]
                    if (isGreen) col.green++ else col.red++
                    col.minY = min(col.minY, y)
                    col.maxY = max(col.maxY, y)
                }
                x += stride
            }
            y += stride
        }

        // A candle usually occupies a narrow consecutive group of active columns.
        val minColumnPixels = max(2, (bottom - top) / (stride * 220))
        val active = BooleanArray(bins) { columns[it].total >= minColumnPixels }
        val groups = mutableListOf<IntRange>()
        var start = -1
        var lastActive = -1
        for (i in 0 until bins) {
            if (active[i]) {
                if (start < 0) start = i
                lastActive = i
            } else if (start >= 0 && i - lastActive > MAX_EMPTY_BINS_BETWEEN_CANDLE_COLUMNS) {
                groups += start..lastActive
                start = -1
                lastActive = -1
            }
        }
        if (start >= 0) groups += start..lastActive

        val detected = groups.mapNotNull { range ->
            val width = range.last - range.first + 1
            if (width < 1 || width > max(18, bins / 22)) return@mapNotNull null
            val greenCount = range.sumOf { columns[it].green }
            val redCount = range.sumOf { columns[it].red }
            val total = greenCount + redCount
            if (total < minColumnPixels * 2 || total == 0) return@mapNotNull null
            val dominance = max(greenCount, redCount).toFloat() / total
            if (dominance < 0.68f) return@mapNotNull null

            val coloredColumns = range.filter { columns[it].total > 0 }
            if (coloredColumns.isEmpty()) return@mapNotNull null
            val candleTop = coloredColumns.minOf { columns[it].minY }
            val candleBottom = coloredColumns.maxOf { columns[it].maxY }
            val height = candleBottom - candleTop + 1
            if (height < max(8, (bottom - top) / 65)) return@mapNotNull null

            // Re-sample actual pixels inside this candidate. The previous implementation
            // filled every row between each column's min/max, which fabricated solid bodies
            // from thin wicks. Count only pixels matching the dominant candle color.
            val rowCounts = IntArray(candleBottom - candleTop + 1)
            val dominantGreen = greenCount >= redCount
            val xStart = left + range.first * binWidth
            val xEnd = min(right - 1, left + (range.last + 1) * binWidth - 1)
            var sampleY = candleTop
            while (sampleY <= candleBottom) {
                var sampleX = xStart
                while (sampleX <= xEnd) {
                    val px = bitmap.getPixel(sampleX, sampleY)
                    val rr = Color.red(px); val gg = Color.green(px); val bb = Color.blue(px)
                    val hiPx = max(rr, max(gg, bb)); val loPx = min(rr, min(gg, bb))
                    val saturatedPx = hiPx - loPx >= 58
                    val greenPx = saturatedPx && gg >= 95 && gg > rr * 1.22f && gg > bb * 1.10f
                    val redPx = saturatedPx && rr >= 105 && rr > gg * 1.22f && rr > bb * 1.10f
                    if ((dominantGreen && greenPx) || (!dominantGreen && redPx)) {
                        rowCounts[sampleY - candleTop]++
                    }
                    sampleX += stride
                }
                sampleY += stride
            }
            val peak = rowCounts.maxOrNull() ?: 0
            if (peak == 0) return@mapNotNull null
            val threshold = max(1, (peak * 0.55f).toInt())
            val bodyRows = rowCounts.indices.filter { rowCounts[it] >= threshold }
            if (bodyRows.isEmpty()) return@mapNotNull null
            val bodyTop = candleTop + bodyRows.first()
            val bodyBottom = candleTop + bodyRows.last()
            val bodyHeight = (bodyBottom - bodyTop + 1).coerceAtLeast(1)
            val wickRatio = ((height - bodyHeight).toFloat() / height).coerceIn(0f, 1f)

            Candle(
                direction = if (greenCount > redCount) "ALTA" else "BAIXA",
                xCenter = left + ((range.first + range.last + 1) * binWidth) / 2,
                top = candleTop,
                bottom = candleBottom,
                bodyTop = bodyTop,
                bodyBottom = bodyBottom,
                wickRatio = wickRatio
            )
        }.sortedBy { it.xCenter }

        val patternMatches = CandlePatternRecognizer.recognize(detected.takeLast(12))
        // Prefer multi-candle formations over generic one-candle shapes when both
        // overlap at the right edge of the chart.
        val rankedPatterns = patternMatches.sortedWith(
            compareByDescending<CandlePatternRecognizer.Match> { it.candles }
                .thenByDescending { it.strength }
        )
        val currentPattern = rankedPatterns.firstOrNull()
        if (detected.size < MIN_CANDLES_FOR_SIGNAL) {
            return Result(
                "AGUARDAR", detected.size, 0,
                "Foram identificados poucos formatos semelhantes a candles (${detected.size}). " +
                    "Deixe o gráfico maior, sem menus sobrepostos, e tente novamente.",
                detected,
                currentPattern?.name ?: "Padrão não identificado",
                currentPattern?.description ?: "Não há candles suficientes/legíveis para reconhecer um padrão.",
                rankedPatterns.map { it.name }
            )
        }

        val recent = detected.takeLast(7)
        val bullish = recent.count { it.direction == "ALTA" }
        val bearish = recent.size - bullish
        val agreement = (100 * max(bullish, bearish) / recent.size).coerceIn(0, 100)
        val recentCandles = detected.takeLast(10)
        val trend = estimateTrend(recentCandles)
        val features = sequenceFeatures(recentCandles)
        val rawPrediction = model?.predict(features)
        // A model label is not allowed to override an unclear visual trend.
        val modelConflict = rawPrediction != null && (
            (rawPrediction.label == "SUBIR" && trend != "ALTA") ||
                (rawPrediction.label == "DESCER" && trend != "BAIXA")
            )
        val signal = when {
            modelConflict -> "AGUARDAR"
            rawPrediction != null -> rawPrediction.label
            bullish >= 6 && agreement >= 85 && trend == "ALTA" -> "SUBIR"
            bearish >= 6 && agreement >= 85 && trend == "BAIXA" -> "DESCER"
            else -> "AGUARDAR"
        }
        val message = when (signal) {
            "SUBIR" -> "Modelo visual indica viés de alta. Confirme tendência, timeframe e contexto."
            "DESCER" -> "Modelo visual indica viés de baixa. Confirme tendência, timeframe e contexto."
            else -> "Evidência insuficiente ou sinais conflitantes; aguarde uma leitura mais clara."
        }
        val source = when {
            modelConflict -> "O modelo sugeriu ${rawPrediction?.label}, mas a tendência visual divergiu; resultado rebaixado para AGUARDAR."
            rawPrediction != null -> "Modelo treinado com ${model?.trainingRows ?: 0} exemplos; score interno ${rawPrediction.score}/100 (não é probabilidade de acerto)."
            else -> "Modelo treinado indisponível: usando regra visual experimental. Concordância de cores $agreement% não é probabilidade de acerto."
        }
        val patternSummary = currentPattern?.let { "Padrão atual: ${it.name} (${it.bias}). ${it.description}" }
            ?: "Padrão atual: nenhum padrão clássico confirmado."
        val trendSummary = "Tendência visual estimada: $trend."
        return Result(
            signal, detected.size, agreement, "$patternSummary $trendSummary $message $source", detected,
            currentPattern?.name ?: "Nenhum padrão clássico confirmado",
            currentPattern?.let { "${it.bias} • ${it.description}" } ?: "Nenhum padrão clássico foi confirmado nos candles detectados.",
            rankedPatterns.map { "${it.name} — ${it.bias}" }, trend
        )
    }


    /**
     * Estimates short-term direction from candle close proxies. Green close is near
     * bodyTop and red close near bodyBottom in screen coordinates (Y grows downward).
     * This is a visual slope, not a price-series trend or a trading forecast.
     */
    internal fun estimateTrend(candles: List<Candle>): String {
        if (candles.size < 5) return "INDEFINIDA"
        val closes = candles.takeLast(8).map {
            if (it.direction == "ALTA") it.bodyTop.toDouble() else it.bodyBottom.toDouble()
        }
        val n = closes.size.toDouble()
        val meanX = (n - 1.0) / 2.0
        val meanY = closes.average()
        var numerator = 0.0
        var denominator = 0.0
        closes.forEachIndexed { index, value ->
            val dx = index - meanX
            numerator += dx * (value - meanY)
            denominator += dx * dx
        }
        if (denominator == 0.0) return "LATERAL"
        val slope = numerator / denominator
        val verticalSpan = (closes.maxOrNull()!! - closes.minOrNull()!!).coerceAtLeast(1.0)
        val normalizedSlope = slope * (n - 1.0) / verticalSpan
        return when {
            normalizedSlope <= -0.12 -> "ALTA" // screen Y decreases as chart price rises
            normalizedSlope >= 0.12 -> "BAIXA"
            else -> "LATERAL"
        }
    }

    /** Six normalized descriptors shared with tools/train_candle_model.py. */
    internal fun sequenceFeatures(candles: List<Candle>): DoubleArray {
        if (candles.isEmpty()) return DoubleArray(CandleSequenceModel.FEATURE_COUNT)
        val directions = candles.map { if (it.direction == "ALTA") 1.0 else -1.0 }
        val bodyRatios = candles.map {
            ((it.bodyBottom - it.bodyTop + 1).toDouble() / (it.bottom - it.top + 1).coerceAtLeast(1)).coerceIn(0.0, 1.0)
        }
        val wickRatios = candles.map { it.wickRatio.toDouble().coerceIn(0.0, 1.0) }
        val n = candles.size.toDouble()
        val weightedMomentum = directions.mapIndexed { index, value -> value * (index + 1) }.sum() /
            ((candles.size * (candles.size + 1) / 2.0).coerceAtLeast(1.0))
        val half = (bodyRatios.size / 2).coerceAtLeast(1)
        val firstMean = bodyRatios.take(half).average()
        val lastMean = bodyRatios.takeLast(half).average()
        return doubleArrayOf(
            directions.sum() / n,
            bodyRatios.average(),
            wickRatios.average(),
            directions.last(),
            weightedMomentum,
            lastMean - firstMean
        )
    }

    private fun waiting(message: String) = Result("AGUARDAR", 0, 0, message)

    private const val MAX_EMPTY_BINS_BETWEEN_CANDLE_COLUMNS = 0
    private const val MIN_CANDLES_FOR_SIGNAL = 5
}
