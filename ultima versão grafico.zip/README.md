# SmartGraphPredictor 3.2.1-beta

Aplicativo Android nativo em Kotlin + Jetpack Compose. Esta versão adiciona a infraestrutura de inferência local de um classificador multiclasses e um pipeline reproduzível para treinamento com exemplos históricos rotulados.

## O que há nesta versão
- Captura de tela Android via MediaProjection, iniciada somente após consentimento do sistema.
- Processamento local, redução de resolução e intervalo entre capturas.
- Detector visual heurístico de componentes semelhantes a candles (não é um detector universal nem leitura OHLC).
- Extração de seis atributos da sequência visual: balanço direcional, proporção média do corpo, pavio médio, direção do último candle, momentum ponderado e variação da proporção do corpo.
- Inferência local opcional com regressão logística softmax de três classes: DESCER, AGUARDAR e SUBIR.
- Abstinência: o modelo retorna AGUARDAR quando score ou margem entre classes não atinge o limite configurado.
- Se não houver modelo treinado instalado, o app identifica isso e usa apenas a regra visual experimental anterior. O arquivo inicial `market_model.json` está deliberadamente marcado `trained: false`.
- Indicadores EMA 9, EMA 21, RSI 14 e MACD para preços informados manualmente.
- Painel flutuante e tela principal.

## Estado real da IA (leia antes de usar)
**Esta entrega não contém um modelo treinado em dados reais.** Não foi fornecido conjunto histórico rotulado. Não seria correto fabricar exemplos e afirmar que a IA foi treinada ou validada. A infraestrutura de treinamento e inferência está pronta; o modelo só passa a ser considerado treinado quando `tools/train_candle_model.py` gerar um arquivo a partir de dados rotulados reais.

O score softmax exibido é uma pontuação interna do classificador, não uma probabilidade calibrada de acerto. Mesmo um bom resultado em teste histórico não garante desempenho futuro.

## Como preparar dados para treinar
1. Colete capturas de gráficos e marque manualmente os candles ou extraia os atributos com um processo de anotação consistente.
2. Para cada janela, calcule exatamente os seis atributos abaixo e rotule o resultado futuro em horizonte fixo como `SUBIR`, `DESCER` ou `AGUARDAR`.
3. Evite vazamento temporal: exemplos de treino devem ser anteriores aos de teste; janelas sobrepostas não devem atravessar as divisões.
4. Inclua custos realistas (spread, taxas e slippage) ao definir os rótulos. Defina o limiar de movimento antes de olhar os resultados.
5. Busque pelo menos 300 exemplos no total e 50 por classe como mínimo inicial; conjuntos maiores e diversos são preferíveis.

CSV obrigatório (`dataset/training_template.csv`):

- `direction_balance`: média dos candles direcionais (+1 alta, -1 baixa).
- `mean_body_ratio`: média de `(bodyBottom-bodyTop+1)/(bottom-top+1)`.
- `mean_wick_ratio`: média do atributo `wickRatio`.
- `last_direction`: +1 para alta, -1 para baixa.
- `weighted_momentum`: média direcional ponderada por posição, pesos 1..N, normalizada pela soma dos pesos.
- `body_ratio_change`: média da metade mais recente menos média da metade inicial da janela.
- `label`: `DESCER`, `AGUARDAR` ou `SUBIR` para o horizonte futuro escolhido.

As features devem ser calculadas para janelas equivalentes às últimas até 10 velas detectadas. A qualidade dos rótulos é responsabilidade do conjunto de dados; não rotule a partir do próprio sinal do app.

## Treinar o modelo
Requer Python 3, sem bibliotecas externas:

```bash
python tools/train_candle_model.py dataset/seu_dataset_rotulado.csv
```

O script mantém a ordem cronológica, treina nos primeiros 70% e avalia no último bloco de 15% (os 15% intermediários ficam como intervalo de separação). Ele grava `app/src/main/assets/market_model.json` e imprime acurácia, balanced accuracy e matriz de confusão. Não use o modelo se o teste estiver fraco ou se houver classes ausentes; ajuste os dados e valide em outro período/mercado.

Depois de treinar, abra no Android Studio e execute:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

## Testes em aparelho
- Teste Android 10+ e autorize a captura na caixa oficial do Android.
- Use gráficos com candles grandes, área visível e sem overlays cobrindo o gráfico.
- Teste tema claro/escuro, cores alternativas, zooms e resoluções.
- Compare candles detectados com anotações manuais e registre falsos positivos em telas sem gráficos.
- Valide o classificador em período totalmente separado e com simulação incluindo custos.
- Pare a captura quando terminar. Apps protegidos podem bloquear captura; não há tentativa de contornar essa proteção.

## Limitações
- A visão computacional ainda depende de cores e geometria; pode confundir candles com indicadores, texto, volume e outros elementos.
- O detector não lê OHLC, escala de preço, ativo, timeframe nem feed de corretora.
- O modelo aprende apenas os seis atributos visuais; não é uma IA multimodal e não vê o contexto completo do mercado.
- Não há dados de mercado em tempo real integrados.
- SUBIR/DESCER/AGUARDAR são resultados experimentais, não recomendação financeira nem promessa de retorno.

## Privacidade
Capturas são processadas no aparelho e não são enviadas a servidores. A captura exige consentimento explícito do Android e mantém notificação de serviço ativo. Não use durante a exibição de informações pessoais.

## Reconhecimento de padrões de candles (3.1.0-beta)

A captura agora passa os candles visuais detectados por `CandlePatternRecognizer`, que procura padrões clássicos de uma, duas, três e cinco velas. Entre eles: Doji (incluindo libélula, lápide e pernas longas), Martelo, Enforcado, Martelo invertido, Estrela cadente, Marubozu, Pião, Engolfos de alta/baixa, Harami de alta/baixa, Linha de perfuração, Cobertura de nuvem escura, Pinça de topo/fundo, Inside Bar, Outside Bar, Estrela da manhã/noite, Três soldados brancos, Três corvos negros e Métodos de alta/baixa de três, Linhas de sustentação/resistência (Belt Hold), Harami cruzado e Três dentro/fora para cima/baixo.

O padrão mais forte encontrado na última sequência é exibido como **Padrão de candle atual** na tela principal e no painel flutuante; padrões adicionais também são listados. As descrições indicam viés técnico possível, não uma previsão.

**Limitações importantes:** os candles são aproximados por cor e geometria de pixels na captura. O detector não lê OHLC diretamente, não verifica gaps com confiabilidade e pode falhar com temas, cores, zoom, indicadores ou desenhos sobrepostos. A identificação é experimental; confirme visualmente e use dados OHLC para uma análise robusta. Se a imagem estiver ambígua, o sinal deve permanecer AGUARDAR.


## Melhorias de leitura visual (3.2.1-beta)

- O cálculo do corpo do candle agora usa contagem de pixels reais por linha dentro do agrupamento, em vez de preencher artificialmente todo o espaço entre o primeiro e o último pixel de cada coluna. Isso reduz a distorção de pavios como se fossem corpo.
- A segmentação deixou de unir colunas ativas através de um espaço vazio, reduzindo a chance de fundir candles vizinhos (pode perder candles muito finos; valide em diferentes zooms).
- A escolha do padrão atual prioriza formações de múltiplos candles antes de padrões genéricos de um candle. A lista exibida segue a mesma ordenação.
- Harami Cross agora exige candle atual com corpo do tipo doji; Harami regular exclui dojis.
- A tendência visual é estimada pela inclinação dos fechamentos aproximados dos últimos candles e exibida no app e na bolha. Em coordenadas de tela, Y menor significa preço visualmente maior.
- Um sinal direcional do modelo treinado é rebaixado para AGUARDAR quando contradiz a tendência visual estimada. A tendência é apenas uma estimativa geométrica da captura, não uma série OHLC.
- Foram adicionados testes unitários para tendência visual e Harami Cross.

## Limites da atualização

A captura ainda não lê candles universais nem OHLC. O algoritmo depende de cores vermelha/verde e pode falhar em temas diferentes, candles vazados, gráficos monocromáticos, indicadores sobrepostos, volume ou baixa resolução. A nova tendência é uma verificação adicional, não prova de direção futura. O projeto ainda precisa ser compilado e testado em dispositivos Android reais.

## Evolução do painel (3.3.0-beta)

- A bolha de resultado continua compacta e pode ser arrastada pela tela.
- Um toque na bolha abre/fecha um painel de resumo.
- O painel mostra sinal, padrão de candle, tendência, confiança visual e quantidade de candles detectados.
- O cabeçalho do painel pode ser arrastado para reposicioná-lo.
- A seção **Ver detalhes** expande a descrição do padrão, outros padrões encontrados e a mensagem técnica da análise; **Ocultar detalhes** recolhe a seção.
- O painel é atualizado quando chega uma nova análise da captura, preservando sua posição e o estado expandido/recolhido.
- A tela completa mantém o monitoramento, os indicadores manuais EMA/RSI/MACD, gráfico de preços, configurações e controle da captura.
- Atualização da versão Android para `3.3.0-beta` (`versionCode 9`).

### Validação desta entrega

Esta atualização foi feita sobre o código-fonte 3.2.1-beta fornecido. Foi realizada revisão estática dos arquivos alterados e verificação da estrutura do ZIP. Não há Gradle Wrapper no pacote e não foi possível executar uma compilação Android completa neste ambiente; portanto, compile e teste em Android Studio antes de instalar. Teste também o movimento do painel em diferentes tamanhos de tela e com os botões de acessibilidade.
