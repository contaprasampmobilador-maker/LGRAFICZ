#!/usr/bin/env python3
"""Train SmartGraphPredictor's tiny on-device softmax classifier.

Input CSV must contain the six feature columns and a label (DESCER, AGUARDAR, SUBIR).
Rows must be chronological; the last 15% are held out for final testing.
Only Python's standard library is required. No synthetic labels are generated.
"""
import argparse, csv, json, math, random, sys
from pathlib import Path

FEATURES = ["direction_balance", "mean_body_ratio", "mean_wick_ratio",
            "last_direction", "weighted_momentum", "body_ratio_change"]
LABELS = ["DESCER", "AGUARDAR", "SUBIR"]


def softmax(logits):
    m = max(logits)
    ex = [math.exp(max(-40.0, min(40.0, x - m))) for x in logits]
    z = sum(ex)
    return [x / z for x in ex]


def load_rows(path):
    rows = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        required = set(FEATURES + ["label"])
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError("CSV precisa conter: " + ",".join(FEATURES + ["label"]))
        for line, row in enumerate(reader, 2):
            label = row["label"].strip().upper()
            if label not in LABELS:
                raise ValueError(f"Linha {line}: label deve ser um de {LABELS}")
            try:
                x = [float(row[k]) for k in FEATURES]
            except Exception as e:
                raise ValueError(f"Linha {line}: feature inválida") from e
            if not all(math.isfinite(v) for v in x):
                raise ValueError(f"Linha {line}: valores não finitos")
            rows.append((x, LABELS.index(label)))
    return rows


def train(rows, epochs=1800, lr=0.035, reg=0.002):
    nfeat = len(FEATURES)
    means = [sum(x[j] for x, _ in rows) / len(rows) for j in range(nfeat)]
    scales = []
    for j in range(nfeat):
        var = sum((x[j] - means[j]) ** 2 for x, _ in rows) / len(rows)
        scales.append(max(math.sqrt(var), 1e-6))
    xs = [[(x[j] - means[j]) / scales[j] for j in range(nfeat)] for x, _ in rows]
    ys = [y for _, y in rows]
    w = [[0.0] * nfeat for _ in LABELS]
    b = [0.0] * len(LABELS)
    for epoch in range(epochs):
        gw = [[0.0] * nfeat for _ in LABELS]
        gb = [0.0] * len(LABELS)
        for x, y in zip(xs, ys):
            p = softmax([b[c] + sum(w[c][j] * x[j] for j in range(nfeat)) for c in range(3)])
            for c in range(3):
                err = p[c] - (1.0 if c == y else 0.0)
                gb[c] += err
                for j in range(nfeat): gw[c][j] += err * x[j]
        rate = lr / len(rows)
        for c in range(3):
            b[c] -= rate * gb[c]
            for j in range(nfeat): w[c][j] -= rate * (gw[c][j] + reg * w[c][j])
    return means, scales, w, b


def predict(model, x):
    means, scales, w, b = model
    z = [(x[j] - means[j]) / scales[j] for j in range(len(FEATURES))]
    p = softmax([b[c] + sum(w[c][j] * z[j] for j in range(len(FEATURES))) for c in range(3)])
    return max(range(3), key=lambda c: p[c]), p


def evaluate(model, rows):
    matrix = [[0] * 3 for _ in range(3)]
    correct = 0
    recalls = []
    for x, y in rows:
        pred, _ = predict(model, x)
        matrix[y][pred] += 1
        correct += pred == y
    for c in range(3):
        denom = sum(matrix[c])
        if denom: recalls.append(matrix[c][c] / denom)
    return {"accuracy": correct / max(1, len(rows)),
            "balanced_accuracy": sum(recalls) / len(recalls) if recalls else 0,
            "confusion_matrix_rows_actual_cols_predicted": matrix,
            "test_rows": len(rows)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", help="CSV rotulado e em ordem cronológica")
    ap.add_argument("--out", default="../app/src/main/assets/market_model.json")
    ap.add_argument("--epochs", type=int, default=1800)
    args = ap.parse_args()
    rows = load_rows(args.csv)
    if len(rows) < 300:
        raise SystemExit(f"Dados insuficientes: {len(rows)} linhas; mínimo 300 recomendado.")
    counts = [sum(y == c for _, y in rows) for c in range(3)]
    if min(counts) < 50:
        raise SystemExit(f"Distribuição insuficiente por classe {dict(zip(LABELS, counts))}; mínimo 50 por classe.")
    split = int(len(rows) * 0.70)
    test_start = int(len(rows) * 0.85)
    train_rows, test_rows = rows[:split], rows[test_start:]
    if len(test_rows) < 45 or any(sum(y == c for _, y in train_rows) == 0 for c in range(3)):
        raise SystemExit("Divisão temporal insuficiente para treino/teste.")
    model = train(train_rows, epochs=args.epochs)
    metrics = evaluate(model, test_rows)
    payload = {
        "schema_version": 1, "trained": True, "training_rows": len(train_rows),
        "labels": LABELS, "feature_names": FEATURES,
        "means": model[0], "scales": model[1], "weights": model[2], "bias": model[3],
        "validation": metrics,
        "note": "Scores softmax não são probabilidades calibradas nem garantia de acerto."
    }
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"model": str(out), "class_counts": dict(zip(LABELS, counts)), **metrics}, indent=2))
    print("Modelo exportado. Revise as métricas e faça validação fora da amostra antes de qualquer uso.")

if __name__ == "__main__":
    try: main()
    except (ValueError, OSError) as exc: sys.exit(str(exc))
