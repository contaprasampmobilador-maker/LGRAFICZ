#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Instale o Gradle 8.7 ou execute este script em um ambiente com Gradle disponível." >&2
  exit 1
fi
gradle wrapper --gradle-version 8.7 --distribution-type bin
echo "Wrapper oficial gerado em gradle/wrapper/."
