# SmartGraphPredictor

Projeto Android educativo em Kotlin + Jetpack Compose Material 3.

## O que está incluído
- Tela principal simplificada, com entrada manual e histórico recolhidos.
- Captura de tela por MediaProjection, sempre mediante autorização do Android.
- Detector visual básico que procura agrupamentos de pixels vermelhos/verdes compatíveis com candles.
- Indicadores EMA 9/21, RSI 14, MACD e reconhecimento de alguns padrões na entrada OHLC manual.
- Painel flutuante opcional.

## Limites do reconhecimento visual
O detector visual é heurístico: identifica agrupamentos coloridos que podem corresponder a candles e estima a predominância de pixels verdes/vermelhos. Ele **não** converte a imagem em preços OHLC, não reconhece com segurança todos os temas/plataformas e não prevê movimentos. Linhas, indicadores, fundos coloridos ou outros elementos do gráfico podem afetar o resultado. A captura é processada localmente e não é enviada a um servidor.

## Build
Requisitos: Android Studio com SDK 34 e JDK 17.

O arquivo `gradle/wrapper/gradle-wrapper.properties` fixa Gradle 8.7. O `gradlew` e `gradlew.bat` incluídos são scripts bootstrap; **o JAR oficial `gradle-wrapper.jar` ainda não está neste pacote** porque o ambiente de montagem não conseguiu acessar o servidor oficial do Gradle. Não substitua esse arquivo por um JAR aleatório. Com Gradle 8.7 instalado, gere o wrapper oficial com:

```bash
gradle wrapper --gradle-version 8.7 --distribution-type bin
```

Depois use `./gradlew assembleDebug` (Linux/macOS) ou `gradlew.bat assembleDebug` (Windows).

## Compatibilidade
AGP 8.5.2, Kotlin 1.9.24, compileSdk 34, minSdk 26, Java 17.

A compilação Android não foi executada neste ambiente. Revise e compile no Android Studio antes de instalar.
