package com.example.smartgraphpredictor.vision

import android.graphics.Bitmap
import kotlin.math.max

data class VisualScan(
    val segments: Int,
    val bullishPixels: Int,
    val bearishPixels: Int,
    val neutralPixels: Int,
    val confidence: Int,
    val summary: String
)

/**
 * Conservative pixel-based screen scanner.
 * It finds clusters of red/green chart pixels that may correspond to candles.
 * It does NOT infer exact OHLC prices or claim to understand every chart theme.
 */
object VisualCandleDetector {
    fun scan(bitmap: Bitmap): VisualScan {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 100 || h < 100) return empty("Imagem pequena demais para analisar.")

        val left = (w * 0.04f).toInt()
        val right = (w * 0.96f).toInt()
        val top = (h * 0.12f).toInt()
        val bottom = (h * 0.88f).toInt()
        val height = bottom - top
        val minPixels = max(2, height / 180)

        val perColumn = IntArray(right - left)
        val greenPerColumn = IntArray(right - left)
        val redPerColumn = IntArray(right - left)
        var green = 0
        var red = 0
        var neutral = 0

        for (x in left until right step 2) {
            for (y in top until bottom step 2) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff
                val idx = x - left
                when {
                    g > 90 && g > r * 1.22 && g > b * 1.08 && g - r > 28 -> {
                        green++
                        perColumn[idx]++
                        greenPerColumn[idx]++
                    }
                    r > 105 && r > g * 1.22 && r > b * 1.12 && r - g > 28 -> {
                        red++
                        perColumn[idx]++
                        redPerColumn[idx]++
                    }
                    else -> neutral++
                }
            }
        }

        val active = perColumn.indices.map { perColumn[it] >= minPixels }
        val gap = max(3, w / 260)
        var groups = 0
        var inGroup = false
        var lastActive = -10000
        for (i in active.indices) {
            if (active[i]) {
                if (!inGroup || i - lastActive > gap) groups++
                inGroup = true
                lastActive = i
            } else if (i - lastActive > gap) {
                inGroup = false
            }
        }

        val colored = green + red
        if (colored < max(120, (w * h) / 1800) || groups < 4) {
            return VisualScan(groups, green, red, neutral, 0,
                "Não encontrei candles coloridos suficientes. Confira se o gráfico está visível e use cores verdes/vermelhas.")
        }

        val dominance = if (colored == 0) 0 else (100.0 * max(green, red) / colored).toInt()
        val bias = when {
            green > red * 1.25 -> "Mais pixels verdes"
            red > green * 1.25 -> "Mais pixels vermelhos"
            else -> "Cores equilibradas"
        }
        val confidence = ((colored.toDouble() / (colored + neutral).coerceAtLeast(1)) * 100).toInt()
            .coerceIn(0, 100)
        val summary = "Possíveis segmentos de candles: $groups. $bias. " +
            "Detecção visual aproximada; não são preços nem previsão."
        return VisualScan(groups, green, red, neutral, minOf(confidence, dominance), summary)
    }

    private fun empty(message: String) = VisualScan(0, 0, 0, 0, 0, message)
}
