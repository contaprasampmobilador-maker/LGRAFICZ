package com.example.smartgraphpredictor.capture

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.example.smartgraphpredictor.vision.VisualCandleDetector

class ScreenCaptureService : LifecycleService() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var lastScanAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        createChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("SmartGraphPredictor")
            .setContentText("Análise visual educativa ativa")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)

        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else readLegacyIntent(intent)

        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    cleanup()
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels,
                PixelFormat.RGBA_8888, 3)
            reader?.setOnImageAvailableListener({ source ->
                val now = SystemClock.elapsedRealtime()
                if (now - lastScanAt < 1200L) {
                    source.acquireLatestImage()?.close()
                    return@setOnImageAvailableListener
                }
                val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                lastScanAt = now
                try {
                    val bitmap = imageToBitmap(image)
                    val result = VisualCandleDetector.scan(bitmap)
                    sendBroadcast(Intent(ACTION_VISUAL_SCAN).setPackage(packageName)
                        .putExtra(EXTRA_VISUAL_SUMMARY, result.summary)
                        .putExtra(EXTRA_VISUAL_COUNT, result.segments)
                        .putExtra(EXTRA_VISUAL_CONFIDENCE, result.confidence))
                    bitmap.recycle()
                } catch (_: Exception) {
                    sendBroadcast(Intent(ACTION_VISUAL_SCAN).setPackage(packageName)
                        .putExtra(EXTRA_VISUAL_SUMMARY, "Não foi possível processar este quadro. Tente outro gráfico.")
                        .putExtra(EXTRA_VISUAL_COUNT, 0)
                        .putExtra(EXTRA_VISUAL_CONFIDENCE, 0))
                } finally {
                    image.close()
                }
            }, Handler(Looper.getMainLooper()))

            display = projection?.createVirtualDisplay("SmartGraphCapture",
                metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface, null, null)
        } catch (_: Exception) {
            cleanup()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height
        val rowPadding = rowStride - pixelStride * width
        val paddedWidth = width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    @Suppress("DEPRECATION")
    private fun readLegacyIntent(intent: Intent?): Intent? = intent?.getParcelableExtra(EXTRA_DATA)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Captura de tela", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun cleanup() {
        try { display?.release() } catch (_: Exception) {}
        try { reader?.setOnImageAvailableListener(null, null); reader?.close() } catch (_: Exception) {}
        display = null
        reader = null
        projection = null
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val CHANNEL = "screen_capture"
        const val NOTIFICATION_ID = 41
        const val ACTION_VISUAL_SCAN = "com.example.smartgraphpredictor.VISUAL_SCAN"
        const val EXTRA_VISUAL_SUMMARY = "visual_summary"
        const val EXTRA_VISUAL_COUNT = "visual_count"
        const val EXTRA_VISUAL_CONFIDENCE = "visual_confidence"
    }
}
