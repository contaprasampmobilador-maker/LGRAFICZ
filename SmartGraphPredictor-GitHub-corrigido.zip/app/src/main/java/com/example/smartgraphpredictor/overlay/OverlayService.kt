package com.example.smartgraphpredictor.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var detailsView: TextView? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel == null) showPanel()
        val result = intent?.getStringExtra(EXTRA_RESULT)
        if (result != null) {
            val pattern = intent.getStringExtra(EXTRA_PATTERN) ?: "Nenhum"
            val indicators = intent.getStringExtra(EXTRA_INDICATORS) ?: "Indisponíveis"
            val reasons = intent.getStringExtra(EXTRA_REASONS) ?: ""
            detailsView?.text = "Resultado: $result\\nPadrão: $pattern\\n$indicators\\n\\n$reasons"
        }
        return START_NOT_STICKY
    }
    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            setBackgroundColor(0xEE101827.toInt())
        }
        val title = TextView(this).apply { text = "SmartGraphPredictor\nAnálise educativa"; setTextColor(0xFF00E5FF.toInt()); textSize = 16f }
        val info = TextView(this).apply {
            text = "Tendência: indisponível\nEMA9/EMA21: —\nRSI/MACD: —\nPadrão: não analisado\nResultado: AGUARDAR\n\nInsira dados válidos na tela principal."
            setTextColor(0xFFFFFFFF.toInt()); textSize = 13f
        }
        detailsView = info
        val buttons = LinearLayout(this)
        buttons.addView(Button(this).apply { text = "Abrir"; setOnClickListener { startActivity(Intent(this@OverlayService, com.example.smartgraphpredictor.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } })
        buttons.addView(Button(this).apply { text = "Minimizar"; setOnClickListener { info.visibility = if (info.visibility == android.view.View.GONE) android.view.View.VISIBLE else android.view.View.GONE } })
        buttons.addView(Button(this).apply { text = "Fechar"; setOnClickListener { stopSelf() } })
        root.addView(title); root.addView(info); root.addView(buttons)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") (WindowManager.LayoutParams.TYPE_PHONE)
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 160 }
        var sx = 0f; var sy = 0f; var wx = 0; var wy = 0
        title.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { sx = event.rawX; sy = event.rawY; wx = params.x; wy = params.y; true }
                MotionEvent.ACTION_MOVE -> { params.x = wx + (event.rawX-sx).toInt(); params.y = wy + (event.rawY-sy).toInt(); try { windowManager?.updateViewLayout(root, params) } catch (_: Exception) {}; true }
                else -> false
            }
        }
        try { windowManager?.addView(root, params); panel = root } catch (_: Exception) { stopSelf() }
    }
    override fun onDestroy() { try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) {}; panel = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_RESULT = "analysis_result"
        const val EXTRA_PATTERN = "analysis_pattern"
        const val EXTRA_INDICATORS = "analysis_indicators"
        const val EXTRA_REASONS = "analysis_reasons"
    }
}
