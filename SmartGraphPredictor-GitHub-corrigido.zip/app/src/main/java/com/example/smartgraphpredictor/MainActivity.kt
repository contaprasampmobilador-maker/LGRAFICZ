package com.example.smartgraphpredictor

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.smartgraphpredictor.analysis.Candle
import com.example.smartgraphpredictor.analysis.TechnicalAnalysis
import com.example.smartgraphpredictor.capture.ScreenCaptureService
import com.example.smartgraphpredictor.history.HistoryEntry
import com.example.smartgraphpredictor.history.HistoryStore
import com.example.smartgraphpredictor.overlay.OverlayService
import java.text.DateFormat
import java.util.Date

private val Navy = Color(0xFF0A0E1A)
private val Cyan = Color(0xFF00D9E8)

class MainActivity : ComponentActivity() {
    private val history by lazy { HistoryStore(this) }
    private val visualStatus = mutableStateOf("Aguardando captura do gráfico.")
    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            visualStatus.value = intent?.getStringExtra(ScreenCaptureService.EXTRA_VISUAL_SUMMARY)
                ?: "Análise visual recebida."
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(ScreenCaptureService.ACTION_VISUAL_SCAN)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(scanReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(scanReceiver, filter)
    }

    override fun onStop() {
        try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 20)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy,
                surface = Color(0xFF151D2E))) {
                Surface(Modifier.fillMaxSize(), color = Navy) {
                    MainScreen(
                        visualStatus = visualStatus.value,
                        onOverlay = { enableOverlay() },
                        onCapture = { launchCapture() },
                        onStopCapture = { stopService(Intent(this, ScreenCaptureService::class.java)) },
                        onAnalysis = { result, pattern, indicators, reasons ->
                            startService(Intent(this, OverlayService::class.java)
                                .putExtra(OverlayService.EXTRA_RESULT, result)
                                .putExtra(OverlayService.EXTRA_PATTERN, pattern)
                                .putExtra(OverlayService.EXTRA_INDICATORS, indicators)
                                .putExtra(OverlayService.EXTRA_REASONS, reasons))
                        },
                        history = history
                    )
                }
            }
        }
    }

    private fun enableOverlay() {
        if (Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
        else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")))
    }

    private fun launchCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
                ContextCompat.startForegroundService(this, intent)
            }
        }
}

@Composable
private fun MainScreen(
    visualStatus: String,
    onOverlay: () -> Unit,
    onCapture: () -> Unit,
    onStopCapture: () -> Unit,
    onAnalysis: (String, String, String, String) -> Unit,
    history: HistoryStore
) {
    var showManual by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var entries by remember { mutableStateOf(history.all()) }
    var candleText by remember { mutableStateOf("") }
    var analysisText by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("SmartGraphPredictor", style = MaterialTheme.typography.headlineMedium, color = Cyan)
        Text("Leitura visual educativa de gráficos", color = Color.LightGray)
        Spacer(Modifier.height(18.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Análise da captura", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text(visualStatus, color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onCapture, modifier = Modifier.fillMaxWidth()) {
                    Text("Capturar e analisar tela")
                }
                OutlinedButton(onClick = onStopCapture, modifier = Modifier.fillMaxWidth()) {
                    Text("Parar captura")
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onOverlay, modifier = Modifier.fillMaxWidth()) {
            Text("Ativar painel flutuante")
        }
        TextButton(onClick = { showManual = !showManual }) {
            Text(if (showManual) "Ocultar entrada manual" else "Entrada manual de candles")
        }

        if (showManual) {
            Text("Um candle por linha: abertura, máxima, mínima, fechamento", color = Cyan)
            OutlinedTextField(
                value = candleText,
                onValueChange = { candleText = it },
                modifier = Modifier.fillMaxWidth().height(140.dp),
                placeholder = { Text("100.0,102.0,99.0,101.0") },
                supportingText = { Text("Use pelo menos 35 linhas e ponto decimal.") }
            )
            Button(onClick = {
                try {
                    val candles = candleText.lines().mapNotNull { line ->
                        val parts = line.trim().split(",", ";", " ", "\t").filter { it.isNotBlank() }
                        if (parts.isEmpty()) null else {
                            require(parts.size == 4) { "Cada linha precisa ter quatro valores OHLC." }
                            Candle(parts[0].toDouble(), parts[1].toDouble(),
                                parts[2].toDouble(), parts[3].toDouble())
                        }
                    }
                    val result = TechnicalAnalysis.analyze(candles)
                    val ind = result.indicators
                    val summary = if (ind == null) "Indicadores indisponíveis" else
                        "EMA9 %.5f · EMA21 %.5f · RSI %.2f · MACD %.5f".format(
                            ind.ema9, ind.ema21, ind.rsi14, ind.macd.line)
                    val pattern = result.pattern?.name ?: "Nenhum"
                    val reasons = result.reasons.joinToString("\n")
                    analysisText = "Leitura: ${result.result}\nPadrão: $pattern\n$summary\n$reasons"
                    onAnalysis(result.result, pattern, summary, reasons)
                    history.add(HistoryEntry(System.currentTimeMillis(), pattern, summary,
                        result.result, reasons))
                    entries = history.all()
                } catch (e: Exception) {
                    analysisText = "Não foi possível analisar: ${e.message ?: "dados inválidos"}"
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Analisar dados") }
            if (analysisText.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(analysisText, color = Color.White)
            }
        }

        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { showHistory = !showHistory; entries = history.all() }) {
            Text(if (showHistory) "Fechar histórico" else "Ver histórico")
        }
        if (showHistory) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Histórico", style = MaterialTheme.typography.titleMedium, color = Cyan)
                TextButton(onClick = { history.clear(); entries = emptyList() }) { Text("Limpar") }
            }
            if (entries.isEmpty()) Text("Nenhuma análise salva.", color = Color.Gray)
            entries.forEach { entry ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(DateFormat.getDateTimeInstance().format(Date(entry.date)))
                        Text("Leitura: ${entry.result}")
                        Text("Padrão: ${entry.pattern}")
                        Text(entry.indicators)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("A leitura visual procura segmentos coloridos que podem ser candles. Não extrai preços OHLC, não prevê movimentos e pode falhar em temas diferentes. Use apenas para estudo.", color = Color(0xFFFFD180), style = MaterialTheme.typography.bodySmall)
    }
}
