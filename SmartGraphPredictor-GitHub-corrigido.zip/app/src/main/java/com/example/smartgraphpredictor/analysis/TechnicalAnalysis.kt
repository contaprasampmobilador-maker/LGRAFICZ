package com.example.smartgraphpredictor.analysis

import kotlin.math.abs

data class Candle(val open: Double, val high: Double, val low: Double, val close: Double, val timestamp: Long = System.currentTimeMillis()) {
    init { require(high >= maxOf(open, close) && low <= minOf(open, close) && high >= low) }
}
data class Macd(val line: Double, val signal: Double, val histogram: Double)
data class Indicators(val ema9: Double, val ema21: Double, val rsi14: Double, val macd: Macd, val trend: String, val cross: String)
data class Pattern(val name: String, val explanation: String)
data class Analysis(val result: String, val reasons: List<String>, val indicators: Indicators?, val pattern: Pattern?)

object TechnicalAnalysis {
    private fun sma(values: List<Double>, period: Int): Double? =
        if (values.size < period) null else values.takeLast(period).average()

    // Seed is the first-period SMA; subsequent values use EMA smoothing k=2/(n+1).
    fun ema(values: List<Double>, period: Int): List<Double> {
        if (period <= 0 || values.size < period) return emptyList()
        val k = 2.0 / (period + 1.0)
        val result = mutableListOf(values.take(period).average())
        for (i in period until values.size) result += values[i] * k + result.last() * (1.0 - k)
        return result
    }

    // Wilder RSI: initial average gain/loss is SMA, then Wilder's recursive smoothing.
    fun rsi(values: List<Double>, period: Int = 14): Double? {
        if (values.size <= period) return null
        var gains = 0.0
        var losses = 0.0
        for (i in 1..period) {
            val delta = values[i] - values[i - 1]
            if (delta >= 0) gains += delta else losses -= delta
        }
        var avgGain = gains / period
        var avgLoss = losses / period
        for (i in period + 1 until values.size) {
            val delta = values[i] - values[i - 1]
            avgGain = (avgGain * (period - 1) + maxOf(delta, 0.0)) / period
            avgLoss = (avgLoss * (period - 1) + maxOf(-delta, 0.0)) / period
        }
        return when {
            avgLoss == 0.0 && avgGain == 0.0 -> 50.0
            avgLoss == 0.0 -> 100.0
            else -> 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
        }
    }

    fun macd(values: List<Double>): Macd? {
        val fast = ema(values, 12)
        val slow = ema(values, 26)
        if (fast.isEmpty() || slow.isEmpty()) return null
        val offset = 26 - 12
        val lineSeries = slow.indices.map { fast[it + offset] - slow[it] }
        val signalSeries = ema(lineSeries, 9)
        if (signalSeries.isEmpty()) return null
        val line = lineSeries.last()
        val signal = signalSeries.last()
        return Macd(line, signal, line - signal)
    }

    fun detectPattern(c: List<Candle>): Pattern? {
        if (c.isEmpty()) return null
        val x = c.last()
        val body = abs(x.close - x.open)
        val range = (x.high - x.low).coerceAtLeast(1e-10)
        val upper = x.high - maxOf(x.open, x.close)
        val lower = minOf(x.open, x.close) - x.low
        val bullish = x.close > x.open
        if (body / range <= 0.1) return Pattern("Doji", "Abertura e fechamento próximos; indica equilíbrio/indecisão, não uma direção garantida.")
        if (lower >= body * 2 && upper <= body && body / range < 0.4)
            return Pattern("Martelo", "Corpo pequeno e sombra inferior longa; pode sugerir rejeição de preços baixos após queda.")
        if (upper >= body * 2 && lower <= body && body / range < 0.4)
            return Pattern("Martelo Invertido", "Sombra superior longa; pode indicar tentativa de alta, que precisa de confirmação.")
        if (c.size >= 2) {
            val p = c[c.lastIndex - 1]
            val prevBear = p.close < p.open
            val prevBull = p.close > p.open
            if (prevBear && bullish && x.open <= p.close && x.close >= p.open)
                return Pattern("Engolfo de Alta", "Corpo comprador envolve o corpo anterior vendedor; possível mudança de pressão.")
            if (prevBull && !bullish && x.open >= p.close && x.close <= p.open)
                return Pattern("Engolfo de Baixa", "Corpo vendedor envolve o corpo anterior comprador; possível mudança de pressão.")
        }
        if (c.size >= 3) {
            val a = c[c.lastIndex - 2]; val b = c[c.lastIndex - 1]
            val midA = (a.open + a.close) / 2
            if (a.close < a.open && abs(b.close - b.open) < (a.high-a.low) * .25 &&
                x.close > x.open && x.close > midA)
                return Pattern("Estrela da Manhã", "Sequência de queda, pausa e candle comprador; possível reversão, sujeita a confirmação.")
            if (a.close > a.open && abs(b.close - b.open) < (a.high-a.low) * .25 &&
                x.close < x.open && x.close < midA)
                return Pattern("Estrela da Noite", "Sequência de alta, pausa e candle vendedor; possível enfraquecimento da alta.")
        }
        return null
    }

    fun analyze(candles: List<Candle>): Analysis {
        if (candles.size < 35) return Analysis("AGUARDAR", listOf("São necessários pelo menos 35 candles válidos; recebidos: ${candles.size}."), null, detectPattern(candles))
        val closes = candles.map { it.close }
        val e9 = ema(closes, 9).last()
        val e21 = ema(closes, 21).last()
        val r = rsi(closes) ?: return Analysis("AGUARDAR", listOf("Não foi possível calcular RSI."), null, null)
        val m = macd(closes) ?: return Analysis("AGUARDAR", listOf("Histórico insuficiente para MACD."), null, null)
        val e9prev = ema(closes.dropLast(1), 9).last()
        val e21prev = ema(closes.dropLast(1), 21).last()
        val cross = when {
            e9prev <= e21prev && e9 > e21 -> "Golden cross"
            e9prev >= e21prev && e9 < e21 -> "Death cross"
            else -> "Sem cruzamento recente"
        }
        val trend = when {
            e9 > e21 * 1.001 -> "ALTA"
            e9 < e21 * .999 -> "BAIXA"
            else -> "LATERAL"
        }
        val indicators = Indicators(e9, e21, r, m, trend, cross)
        val reasons = mutableListOf("Tendência: $trend.", "Cruzamento: $cross.", "RSI 14: %.2f.".format(r), "MACD: %.5f; sinal: %.5f; histograma: %.5f.".format(m.line,m.signal,m.histogram))
        val score = (if (e9 > e21) 1 else -1) + (if (m.histogram > 0) 1 else -1) + (if (r in 50.0..70.0) 1 else if (r < 50) -1 else 0)
        val result = when { score >= 2 -> "TENDÊNCIA DE ALTA"; score <= -2 -> "TENDÊNCIA DE BAIXA"; else -> "SEM TENDÊNCIA CLARA" }
        val pattern = detectPattern(candles)
        reasons += if (pattern != null) "Padrão: ${pattern.name} — ${pattern.explanation}" else "Nenhum padrão reconhecido no último candle."
        reasons += "Leitura didática de dados históricos; não é recomendação financeira nem previsão de preços."
        return Analysis(result, reasons, indicators, pattern)
    }
}
