package com.example.smartgraphpredictor.history

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val date: Long, val pattern: String, val indicators: String, val result: String, val reasons: String)

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("analysis_history", Context.MODE_PRIVATE)
    @Synchronized fun all(): List<HistoryEntry> = try {
        val a = JSONArray(prefs.getString("entries", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            HistoryEntry(o.optLong("date"), o.optString("pattern"), o.optString("indicators"), o.optString("result"), o.optString("reasons"))
        }.reversed()
    } catch (_: Exception) { emptyList() }

    @Synchronized fun add(entry: HistoryEntry) {
        val a = JSONArray()
        (all().reversed() + entry).takeLast(200).forEach {
            a.put(JSONObject().put("date",it.date).put("pattern",it.pattern).put("indicators",it.indicators).put("result",it.result).put("reasons",it.reasons))
        }
        prefs.edit().putString("entries", a.toString()).apply()
    }
    fun clear() { prefs.edit().remove("entries").apply() }
}
