@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (gradle %*) & exit /b %ERRORLEVEL%
set VER=8.7
set BASE=%USERPROFILE%\.gradle\smartgraph-bootstrap
set BIN=%BASE%\gradle-%VER%\bin\gradle.bat
if not exist "%BIN%" (
  if not exist "%BASE%" mkdir "%BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest https://services.gradle.org/distributions/gradle-%VER%-bin.zip -OutFile '%BASE%\gradle.zip'; Expand-Archive -Force '%BASE%\gradle.zip' '%BASE%'"
)
call "%BIN%" %*
